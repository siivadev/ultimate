export type PageProps = {
  // Add custom props here
};
