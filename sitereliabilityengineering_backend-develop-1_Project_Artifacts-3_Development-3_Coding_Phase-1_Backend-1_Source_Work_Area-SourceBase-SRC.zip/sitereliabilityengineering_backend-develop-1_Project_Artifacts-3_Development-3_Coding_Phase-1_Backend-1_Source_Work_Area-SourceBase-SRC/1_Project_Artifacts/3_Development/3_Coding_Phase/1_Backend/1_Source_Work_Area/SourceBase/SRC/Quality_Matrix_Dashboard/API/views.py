from django.http import JsonResponse, HttpResponseBadRequest,HttpResponse
from rest_framework.decorators import api_view
from django.views.decorators.csrf import csrf_exempt
import jenkins,time,json,subprocess,os,requests
from jenkinsapi.jenkins import Jenkins
from dotenv import load_dotenv
from .Mysql_Adapter import MysqlAdapter
from collections import defaultdict


load_dotenv()
host = os.getenv("jenkins_url") # Jenkins url here
username = os.getenv('jenkins_username')  # Jenkins username here
token = os.getenv('jenkins_token')  # Jenkins user token / API token here
timeout=10
access_token = os.getenv("gitlab_token")
project_id=os.getenv("gitlab_project_id")
gitlab_url=os.getenv("gitlab_url")

server = jenkins.Jenkins(host, username=username, password=token,timeout=timeout)
jenkins_server = Jenkins(host, username=username, password=token,timeout=timeout)

job_name = os.getenv("jenkins_job_name") #Name of jenkins job
job = jenkins_server[job_name]

@csrf_exempt
@api_view(['GET'])
def commit(request):
    if request.method == 'GET':
        try:
            # Make a request to the GitLab API to get the commits
            url = f"{gitlab_url}/api/v4/projects/{project_id}/repository/commits"
            headers = {"Authorization": f"Bearer {access_token}"}

            response = requests.get(url, headers=headers)
            commits = response.json()
            commit_data =[]
            author_stats = defaultdict(lambda: {"additions": 0, "deletions": 0})

            for commit in commits:
                commit_id = commit["id"]
                commit_details_url = f"{gitlab_url}/api/v4/projects/{project_id}/repository/commits/{commit_id}"
                commit_details_response = requests.get(commit_details_url, headers=headers)
                commit_details = commit_details_response.json()

                if "stats" in commit_details:
                    stats = commit_details["stats"]
                    additions = stats["additions"]
                    deletions = stats["deletions"]
                    # total_changes = stats["total"]

                    author_name = commit_details["author_name"]
                    commit_date = commit_details["committed_date"]
                    
                    files_changed = 0
                    if "changes" in commit_details:
                        files_changed = len(commit_details["changes"])

                    author_stats[author_name]["additions"] += additions
                    author_stats[author_name]["deletions"] += deletions
                    commit_details = {
                            "commit_id": commit_id,
                            "author": author_name,
                            "date": commit_date,
                            "files_changed": files_changed,
                            "additions": additions,
                            "deletions": deletions,
                            "project_id":project_id,
                            # "build_unique_refer_id" :321,
                        }
                    commit_data.append(commit_details)
                    print(commit_data)

                    # Save commit data using the MysqlAdapter
            adapter = MysqlAdapter()
            adapter.save_commit_data(commit_data)

            # Print the code metrics for each author
            for author, stats in author_stats.items():
                print(f"Author: {author}")
                print("Added lines:", stats["additions"])
                print("Deleted lines:", stats["deletions"])
                print("Productivity =", stats["additions"] - stats["deletions"])
                
            
            
            return JsonResponse({'status': 'success'})    
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    else:
        return HttpResponseBadRequest()


# start build ,get log ,store to db
def build(request):
    if request.method == 'GET':
        try:
            # print("Triggering build...")
            last_build_number = job.get_last_buildnumber()
            job.invoke()
            while True:
                # print('Waiting for build to start...')
                time.sleep(3)
                last_build = job.get_last_build()
                if last_build.get_number() != last_build_number:
                    break
            # print('Running...')
            while last_build.is_running():
                time.sleep(1)
                last_build = job.get_last_build()
            build_status = last_build.get_status()
            # Using Jenkins API, get the build info
            last_complete_build = server.get_job_info(job_name)['lastCompletedBuild']['number']
            console_output = server.get_build_console_output(job_name, last_complete_build)
            # Write the data into a text file
            file_name = "static/log/Build_log_" + str(last_complete_build) + ".txt"
            file2 = open(file_name, "w+")
            file2.write(console_output)
            file2.close()
            return JsonResponse({'status': build_status})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    else:
        return HttpResponseBadRequest()

# Run a build and get build number and more info using api
def build_start(request):
    if request.method == 'GET':
        try:
            server.build_job(job_name)
            last_build_number = server.get_job_info(job_name)['lastCompletedBuild']['number']
            print("Build Number", last_build_number)
            build_info = server.get_build_info(job_name, last_build_number)
            print("build info", build_info)
            return JsonResponse({'status': 'Build started successfully'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    else:
        return HttpResponseBadRequest()
       
# Stop a build using api
def build_stop(request):
    if request.method == 'GET':
        try:
            last_build_number = server.get_job_info(job_name)['lastCompletedBuild']['number']
            server.stop_build(job_name, last_build_number+1)
           
            return JsonResponse({'status': 'Build stopped successfully'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    else:
        return HttpResponseBadRequest()    

# Get Console log of a specific build and download it in a text file using api
@api_view(['GET','POST'])
def build_log(request):
    if request.method == 'GET':
        try:
            # Using Jenkins API, get the build info
            last_complete_build = server.get_job_info(job_name)['lastCompletedBuild']['number']
            console_output = server.get_build_console_output(job_name, last_complete_build)
            # Write the data into a text file 
            file_name = "static/log/Build_log_" + str(last_complete_build) + ".txt"
            file2 = open(file_name, "w+")
            file2.write(console_output)
            file2.close()
            return JsonResponse({'status': 'Build log downloaded successfully'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    else:
        return HttpResponseBadRequest()

# Get status of build using subprocess
def build_status(request):
    if request.method == 'GET':
        try:
            curl_command = f'curl -g -u {username}:{token} "{host}/job/{job_name}/lastBuild/api/json"'
            result = subprocess.run(curl_command, shell=True, check=True, capture_output=True, text=True)
            json_data = json.loads(result.stdout)

            user_name = json_data.get('actions', [{}])[0].get('causes', [{}])[0].get('userName', '')
            result = json_data.get('result', '')
            building = json_data.get('building', False)
            full_display_name = json_data.get('fullDisplayName', '')
            job_id = json_data.get('id', '')

            if full_display_name:
                display_name_parts = full_display_name.split()
                job_name_parts = display_name_parts[:-1]  # Exclude the last part
                jobname = ' '.join(job_name_parts)
            response_data = {
                'Username': user_name,
                'Build_result': result,
                'Build_status': building,
                'Job_name': jobname,
                'Build_no': job_id
            }
            return JsonResponse(response_data)
        except subprocess.CalledProcessError as e:
            return JsonResponse({'status': 'error', 'message': str(e), 'output': e.output})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    else:
        return HttpResponseBadRequest()

# Run a build using subprocess
def build_start_sub(request):
    if request.method == 'GET':
        try:
            subprocess.Popen(f'curl -X POST -L --user {username}:{token} "{host}/job/{job_name}/build/start"', shell=True)  
            return JsonResponse({'status': 'Build started successfully'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
    else:
        return HttpResponseBadRequest()

# Stop a build using subprocess
def build_stop_sub(request):
     if request.method == 'GET':
        try:
            subprocess.Popen(f'curl -X POST -L --user {username}:{token} "{host}/job/{job_name}/lastBuild/stop"', shell=True)
            return JsonResponse({'status': 'Stopped the build succesfully'})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)})
     else:
        return HttpResponseBadRequest()
     

#loc based on project
@csrf_exempt
@api_view(['GET'])
def cloc(request):
    if request.method == 'GET':
        p = subprocess.Popen(r"C:\\ProgramData\\Jenkins\\.jenkins\workspace\\cloc C:\\ProgramData\\Jenkins\\.jenkins\\workspace\\Technology", shell=True, cwd=r"C:\\ProgramData\\Jenkins\\.jenkins\\workspace\\Technology", stdout=subprocess.PIPE)
        out, err = p.communicate()
        msg = out.decode('utf-8')
        
        # Split the output into lines
        lines = msg.strip().split('\n')

        # Initialize an empty list to store the language data
        language_data = []

        # Iterate over the lines starting from the third line
        for line in lines[3:]:
            # Skip the line if it starts with 'SUM:'
            if line.startswith('SUM:'):
                continue

            # Split the line into values
            values = line.split()

            # Check if the values list has the required number of elements
            if len(values) >= 5:
                try:
                    # Extract the language and its corresponding values
                    language = values[0]
                    file_count = int(values[1])
                    blank_count = int(values[2])
                    comment_count = int(values[3])
                    code_count = int(values[4])

                    # Create a dictionary with the extracted values
                    language_info = {
                        'language': language,
                        'files': file_count,
                        'blank': blank_count,
                        'comment': comment_count,
                        'code': code_count
                    }

                    # Append the language information to the list
                    language_data.append(language_info)
                except ValueError:
                    print(f"Skipping line due to invalid value: {line}")
            else:
                print(f"Skipping line: {line}")

        # Insert the language data into the MySQL database using the adapter
        adapter = MysqlAdapter()
        for language_info in language_data:
            adapter.save_cloc_data(
                language_info['language'],
                language_info['files'],
                language_info['blank'],
                language_info['comment'],
                language_info['code']
            )

        return HttpResponse("Data saved successfully!")
    else:
        return HttpResponse("Invalid request method. Only POST is allowed.")







         






