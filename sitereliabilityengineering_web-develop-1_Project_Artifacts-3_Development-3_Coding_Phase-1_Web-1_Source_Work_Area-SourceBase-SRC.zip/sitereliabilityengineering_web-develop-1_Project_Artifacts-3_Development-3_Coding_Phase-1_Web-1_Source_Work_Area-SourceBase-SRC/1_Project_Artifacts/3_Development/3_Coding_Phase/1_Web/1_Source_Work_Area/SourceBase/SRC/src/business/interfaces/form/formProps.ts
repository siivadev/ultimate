import { UseFormRegister } from 'react-hook-form';
import { ReactNode } from 'react';
import { ButtonProps } from '../button';
import { InputProps } from '../input';
import { SelectProps } from '../select';

type InputType = SelectProps & InputProps;
type MultiColumn = {
  key?: string;
  wrapperClass?: string;
  columns?: InputType[];
};
export type FormFieldType = SelectProps & InputProps & MultiColumn;
export interface FormProps {
  fields: FormFieldType[];
  register?: UseFormRegister<any>;
  errors?: any;
  submitButtonText: string;
  submitButtonClass?: string;
  handleSubmit?: (inputFields: any) => void;
  additionalButtons?: ButtonProps[];
  children?: ReactNode;
}
