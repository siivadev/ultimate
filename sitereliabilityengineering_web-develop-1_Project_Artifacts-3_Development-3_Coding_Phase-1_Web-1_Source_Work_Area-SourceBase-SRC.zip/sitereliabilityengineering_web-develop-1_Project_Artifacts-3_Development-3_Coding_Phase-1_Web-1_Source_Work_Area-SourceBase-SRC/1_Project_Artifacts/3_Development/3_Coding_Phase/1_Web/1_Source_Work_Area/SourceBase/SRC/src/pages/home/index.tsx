import type {
  NextPage,
  GetServerSideProps,
  InferGetServerSidePropsType
} from 'next';
import { serverSideTranslations } from 'next-i18next/serverSideTranslations';
// import { Home } from '@business/workflows/ComponentViews';
import { SignIn } from '@business/workflows/ComponentViews';
import type { PageProps } from '@business/interfaces/page';

const HomePage: NextPage = (
  _props: InferGetServerSidePropsType<typeof getServerSideProps>
) => <SignIn />;

export const getServerSideProps: GetServerSideProps<PageProps> = async ({
  locale
}) => ({
  props: {
    ...(await serverSideTranslations(locale ?? 'en', ['common']))
  }
});

export default HomePage;
