import React, { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import { ComponentProviderProps } from '@business/interfaces/component-provider';
import { routePaths } from '@utils/constants/routePaths';
import { getToken } from '@ports/common/sessionStateSlice';

const authUrls = [
  '/',
  routePaths.SignIn
  //routePaths.ResetPassword
];
/*
 * This component is used redirect the user to corresponding page if user is logged in
 */
export function AuthGuard({ children }: ComponentProviderProps) {
  const router = useRouter();
  const token = useSelector(getToken);

  useEffect(() => {
    if (token && authUrls.includes(router.pathname)) {
      router.push(routePaths.Dashboard);
    } else if (!token && !authUrls.includes(router.pathname)) {
      router.push(routePaths.SignIn);
    }
  }, [router.pathname, token]);

  return <>{children}</>;
}
