import { UseFormRegister } from 'react-hook-form';
import { ButtonProps } from '../button';
export interface FormElementProps {
  register?: UseFormRegister<any>;
  errors?: any;
  submitButtonClass?: string;
  handleSubmit?: (inputFields: any) => void;
  additionalButtons?: ButtonProps[];
}
