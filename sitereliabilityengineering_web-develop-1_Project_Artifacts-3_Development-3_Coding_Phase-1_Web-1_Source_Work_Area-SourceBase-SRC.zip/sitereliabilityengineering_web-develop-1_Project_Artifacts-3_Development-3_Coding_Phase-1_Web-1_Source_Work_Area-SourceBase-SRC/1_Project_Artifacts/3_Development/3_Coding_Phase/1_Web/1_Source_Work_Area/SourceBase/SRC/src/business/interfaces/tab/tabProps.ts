type tabs = {
  value: string;
  content: string;
};

export interface TabProps {
  color?: 'primary' | 'secondary ';
  size?: 'small' | 'medium' | 'large';
  disabled?: boolean;
  label?: string;
  //controlled?: boolean;
  startIcon?: string;
  onClick?: () => void;
  wrapperClass?: string;
  tabs?: tabs[];
  activeTab?: number;
  content?: string;
  defaultActiveTab?: boolean;
}
