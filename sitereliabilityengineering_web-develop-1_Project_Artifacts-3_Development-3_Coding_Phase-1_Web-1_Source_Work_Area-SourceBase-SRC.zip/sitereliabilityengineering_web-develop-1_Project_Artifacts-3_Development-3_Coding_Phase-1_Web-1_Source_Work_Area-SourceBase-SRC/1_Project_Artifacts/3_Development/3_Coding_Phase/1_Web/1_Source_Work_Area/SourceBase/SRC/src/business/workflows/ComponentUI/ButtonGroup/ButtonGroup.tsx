import { FC } from 'react';
import { ButtonGroupProps } from '@business/interfaces/button-group';
import { Button } from '../Button';

export const ButtonGroup: FC<ButtonGroupProps> = ({ buttons, ...props }) => {
  return (
    <>
      <div
        className="inline-flex rounded-md shadow-sm button-group"
        role="group"
        data-testid="button-group">
        {buttons.map((button, index) => (
          <Button
            key={index}
            {...props}
            href={button?.href}
            isDisabled={button?.isDisabled}
            startIcon={button?.startIcon}
            endIcon={button?.endIcon}
            className={`${props.className} `}>
            {button?.label}
          </Button>
        ))}
      </div>
    </>
  );
};
