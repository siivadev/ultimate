import { render, screen } from '@testing-library/react';
import { generateField } from './generateField';

describe('GenerateField', () => {
  it('returns an InputField component for an unknown type', () => {
    const field = {
      label: 'Enter Organization Name',
      name: 'organizationName',
      type: 'text'
    };
    render(generateField(field));
    expect(screen.getByTestId(`input-field-${field.name}`)).toBeInTheDocument();
  });

  it('returns a Select component when type is select ', () => {
    const field = {
      label: 'Enter Organization Name',
      name: 'organizationName',
      type: 'select',
      options: [{ label: 'option 1 ', value: 'option1' }]
    };
    render(generateField(field));
    expect(
      screen.getByTestId(`select-input-${field.name}`)
    ).toBeInTheDocument();
  });

  it('returns a Checkbox component when type is checkbox ', () => {
    const field = {
      label: 'Enter Organization Name',
      name: 'organizationName',
      type: 'checkbox',
      options: [{ label: 'option 1 ', value: 'option1' }]
    };
    render(generateField(field));
    expect(screen.getByTestId('checkbox-field')).toBeInTheDocument();
  });

  it('returns a RadioGroup component when type is radio ', () => {
    const field = {
      label: 'Enter Organization Name',
      name: 'organizationName',
      type: 'radio',
      options: [{ label: 'option 1 ', value: 'option1' }]
    };
    render(generateField(field));
    expect(
      screen.getByTestId(`select-input-${field.name}`)
    ).toBeInTheDocument();
  });
});
