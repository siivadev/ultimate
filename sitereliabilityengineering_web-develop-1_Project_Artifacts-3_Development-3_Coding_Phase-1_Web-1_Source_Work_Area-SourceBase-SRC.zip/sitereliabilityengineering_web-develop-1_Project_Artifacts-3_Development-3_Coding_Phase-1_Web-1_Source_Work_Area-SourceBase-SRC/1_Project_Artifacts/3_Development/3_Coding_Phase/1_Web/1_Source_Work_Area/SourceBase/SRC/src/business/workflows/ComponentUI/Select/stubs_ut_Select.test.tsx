import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import { Select } from './Select';

describe('Select', () => {
  const options = [
    { label: 'Option 1', value: 'option1' },
    { label: 'Option 2', value: 'option2' },
    { label: 'Option 3', value: 'option3' }
  ];
  const label = 'Select an option';
  const name = 'select';

  it('renders label and options correctly', () => {
    render(<Select label={label} name={name} options={options} />);
    const selectElement = screen.getByTestId(`select-input-${name}`);
    expect(selectElement).toBeInTheDocument();
    options.forEach(option => {
      expect(screen.getByTestId(option.value)).toBeInTheDocument();
    });
  });
  it('calls the onChange function when the input value changes', () => {
    const name = 'text';
    const onChange = jest.fn();
    const { getByTestId } = render(
      <Select onChange={onChange} name={name} options={options} />
    );
    const inputElement = getByTestId(`select-input-${name}`);
    fireEvent.change(inputElement, { target: { value: 'option1' } });
    expect(onChange).toHaveBeenCalledTimes(1);
  });
  it('renders an error message when the error prop is passed', () => {
    const { getByText } = render(
      <Select error="Invalid input" options={options} />
    );
    const errorElement = getByText('Invalid input');
    expect(errorElement).toBeInTheDocument();
  });
  it('renders start and end icons when provided', () => {
    const { getByTestId } = render(
      <Select
        startDecorator={<i data-testid="start-icon" />}
        endDecorator={<i data-testid="end-icon" />}
        options={options}
      />
    );
    expect(getByTestId('start-icon')).toBeInTheDocument();
    expect(getByTestId('end-icon')).toBeInTheDocument();
  });
});
