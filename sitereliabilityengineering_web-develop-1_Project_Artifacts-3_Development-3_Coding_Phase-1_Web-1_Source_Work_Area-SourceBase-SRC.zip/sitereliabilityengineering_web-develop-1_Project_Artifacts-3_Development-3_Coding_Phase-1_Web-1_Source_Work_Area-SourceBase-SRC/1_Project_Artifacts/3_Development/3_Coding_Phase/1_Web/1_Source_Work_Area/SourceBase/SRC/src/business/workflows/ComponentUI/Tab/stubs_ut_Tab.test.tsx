import { render, fireEvent } from '@testing-library/react';
import { Tab } from './Tab';

describe('Tab component', () => {
  const tabs = [
    { value: 'Tab 1', content: 'Tab 1 Content' },
    { value: 'Tab 2', content: 'Tab 2 Content' },
    { value: 'Tab 3', content: 'Tab 3 Content' }
  ];

  it('should render tabs with correct labels', () => {
    const { getByText } = render(<Tab tabs={tabs} />);
    tabs.forEach(tab => {
      expect(getByText(tab.value)).toBeInTheDocument();
    });
  });

  it('should render first tab as active by default', () => {
    const { getByText } = render(<Tab tabs={tabs} />);
    expect(getByText('Tab 1')).toHaveClass(`"tab tab-bordered"`);
  });

  it('should switch active tab when clicked', () => {
    const { getByText } = render(<Tab tabs={tabs} />);
    fireEvent.click(getByText('Tab 2'));
    expect(getByText('Tab 1')).not.toHaveClass('tab-active');
    expect(getByText('Tab 2')).toHaveClass(`"tab tab-bordered"`);
  });

  //   it('should render correct tab content when tab is clicked', () => {
  //     const { getByText } = render(<Tab tabs={tabs} />);
  //     fireEvent.click(getByText('Tab 2'));
  //     //expect(getByText('Tab 1 Content')).not.toBeVisible();
  //     expect(getByText('Tab 2 Content')).toBeVisible();
  //     //expect(getByText('Tab 3 Content')).not.toBeVisible();
  //   });
});
