import React from 'react';
import { render } from '@testing-library/react';
import { ProgressBar } from './ProgressBar';

describe('ProgressBar', () => {
  test('renders progress percentage correctly', () => {
    const props = {
      progress: 50,
      className: 'progress-bar',
      wrapperClass: 'progress-wrapper'
    };
    const { getByText } = render(<ProgressBar {...props} />);
    expect(getByText('50%')).toBeInTheDocument();
  });

  test('renders with the correct class names', () => {
    const props = {
      progress: 25,
      className: 'progress-bar',
      wrapperClass: 'progress-wrapper'
    };
    const { container } = render(<ProgressBar {...props} />);
    expect(container.firstChild).toHaveClass('progress-bar');
    expect(container.firstChild.firstChild).toHaveClass('progress-wrapper');
  });
});
