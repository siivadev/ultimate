import { render } from '@testing-library/react';
import { RadialProgress } from './RadialProgress';

describe('RadialProgress', () => {
  it('renders the progress bar with custom progress and label', () => {
    const progress = 50;
    const label = 'complete';
    const { getByRole, getByText } = render(
      <RadialProgress progress={progress} label={label} />
    );
    const progressElement = getByRole('progressbar');
    expect(progressElement).toBeInTheDocument();
    const labelRegex = new RegExp(`${progress}% ${label}`);
    const labelElement = getByText(labelRegex);
    expect(labelElement).toBeInTheDocument();
  });
});
