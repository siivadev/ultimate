import type { ReactNode } from 'react';

type BreadcrumbItem = {
  label: string;
  link: string;
  icon?: ReactNode;
};

export type BreadcrumbsProps = {
  items: BreadcrumbItem[];
  separator: ReactNode;
};
