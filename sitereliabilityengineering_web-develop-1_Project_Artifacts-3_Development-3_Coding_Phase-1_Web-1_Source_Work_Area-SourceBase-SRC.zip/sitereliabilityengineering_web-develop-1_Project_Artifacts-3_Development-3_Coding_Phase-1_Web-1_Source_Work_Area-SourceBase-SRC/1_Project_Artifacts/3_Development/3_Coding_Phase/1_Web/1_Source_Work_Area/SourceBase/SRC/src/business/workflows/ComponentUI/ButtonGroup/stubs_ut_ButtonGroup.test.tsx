import React from 'react';
import { render, screen } from '@testing-library/react';
import { Button } from '@business/interfaces/button';
import { ButtonGroup } from './ButtonGroup';

describe('ButtonGroup ', () => {
  test('renders component', () => {
    const buttons: Button[] = [
      {
        label: 'Profile'
      },
      {
        label: 'Settings'
      }
    ];
    render(<ButtonGroup buttons={buttons} />);
    expect(screen.getByTestId('button-group')).toBeInTheDocument();
    expect(screen.getAllByTestId('button-tag')).toHaveLength(2);
  });
});
