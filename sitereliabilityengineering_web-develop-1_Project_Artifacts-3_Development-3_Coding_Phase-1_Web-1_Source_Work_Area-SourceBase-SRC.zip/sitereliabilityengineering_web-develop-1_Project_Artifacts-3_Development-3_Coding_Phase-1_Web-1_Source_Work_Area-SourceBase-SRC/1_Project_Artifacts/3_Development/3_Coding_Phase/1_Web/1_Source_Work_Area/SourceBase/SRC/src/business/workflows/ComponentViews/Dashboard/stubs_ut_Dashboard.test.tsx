import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ComponentProvider } from '@business/workflows/ComponentHigherOrder';
import { Dashboard } from './Dashboard';

function DashboardComponent() {
  return (
    <ComponentProvider>
      <Dashboard />
    </ComponentProvider>
  );
}

describe('Dashboard', () => {
  beforeEach(() => {
    render(<DashboardComponent />);
  });
  it('renders the page title', () => {
    expect(screen.getByTestId('dashboard-title')).toBeInTheDocument();
  });

  it('renders the upload button', () => {
    expect(screen.getByTestId('upload-button')).toBeInTheDocument();
  });

  it('opens the file picker when upload button is clicked', async () => {
    const uploadButton = screen.getByTestId('upload-button');
    const fileInput = screen.getByTestId('file-input');
    expect(fileInput).toBeVisible();

    await userEvent.click(uploadButton);
    expect(fileInput).toBeVisible();
  });

  it('renders the member list', () => {
    expect(screen.getByTestId('member-list')).toBeInTheDocument();
  });

  it('renders the member table with correct columns', () => {
    expect(screen.getByTestId('table-name')).toBeInTheDocument();
    expect(screen.getByTestId('table-mail')).toBeInTheDocument();
    expect(screen.getByTestId('table-member')).toBeInTheDocument();
    expect(screen.getByTestId('table-interest')).toBeInTheDocument();
    expect(screen.getByTestId('table-status')).toBeInTheDocument();
    expect(screen.getByTestId('table-actions')).toBeInTheDocument();
  });
});
