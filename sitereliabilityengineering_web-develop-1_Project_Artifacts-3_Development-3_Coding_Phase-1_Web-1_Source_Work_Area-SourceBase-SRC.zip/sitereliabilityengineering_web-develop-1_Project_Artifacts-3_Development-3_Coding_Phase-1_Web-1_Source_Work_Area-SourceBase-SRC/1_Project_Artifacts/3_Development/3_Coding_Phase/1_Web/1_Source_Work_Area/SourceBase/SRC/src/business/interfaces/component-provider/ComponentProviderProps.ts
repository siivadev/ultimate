import type { ReactNode } from 'react';

export interface ComponentProviderProps {
  children?: ReactNode;
}
