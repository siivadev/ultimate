export interface PaginationProps {
  totalCount?: number;
  currentPage?: number;
  pageSize?: number;
  onPageChange?: (pages: any) => void;
  siblingCount?: number;
  dots?: string;
}
