import type { ReactNode } from 'react';

export interface ButtonProps {
  type?: 'button' | 'submit' | 'reset';
  btnStyle?: 'primary' | 'secondary' | 'default-outline' | 'link';
  className?: string;
  onClick?: () => void;
  isDisabled?: boolean;
  size?: 'small' | 'medium' | 'large';
  fullWidth?: boolean;
  href?: string;
  label?: string;
  startIcon?: ReactNode;
  endIcon?: ReactNode;
  loading?: boolean;
  children?: ReactNode;
}
