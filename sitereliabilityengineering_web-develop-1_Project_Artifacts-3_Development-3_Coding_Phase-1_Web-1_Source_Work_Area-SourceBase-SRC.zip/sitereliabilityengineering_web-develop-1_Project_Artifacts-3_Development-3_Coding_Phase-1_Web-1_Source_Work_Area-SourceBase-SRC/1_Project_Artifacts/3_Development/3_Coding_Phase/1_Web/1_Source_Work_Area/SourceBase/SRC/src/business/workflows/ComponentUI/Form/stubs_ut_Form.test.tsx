import { render, screen, fireEvent } from '@testing-library/react';
import { Form } from './Form';

describe('Form component', () => {
  const mockFields = [
    { name: 'name', label: 'Name', type: 'text' },
    { name: 'email', label: 'Email', type: 'email' },
    { name: 'password', label: 'Password', type: 'password' }
  ];

  const mockSubmitButtonText = 'Submit';
  const mockHandleSubmit = jest.fn();
  const mockRegister = jest.fn();
  const mockErrors = {};

  it('renders form fields and submit button', () => {
    render(
      <Form
        fields={mockFields}
        submitButtonText={mockSubmitButtonText}
        handleSubmit={mockHandleSubmit}
        register={mockRegister}
        errors={mockErrors}
      />
    );

    expect(screen.getByLabelText('Name')).toBeInTheDocument();
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Password')).toBeInTheDocument();
    expect(screen.getByText(mockSubmitButtonText)).toBeInTheDocument();
  });

  it('calls handleSubmit function when submit button is clicked', () => {
    render(
      <Form
        fields={mockFields}
        submitButtonText={mockSubmitButtonText}
        handleSubmit={mockHandleSubmit}
        register={mockRegister}
        errors={mockErrors}
      />
    );

    fireEvent.click(screen.getByText(mockSubmitButtonText));

    expect(mockHandleSubmit).toHaveBeenCalledTimes(1);
  });
});
