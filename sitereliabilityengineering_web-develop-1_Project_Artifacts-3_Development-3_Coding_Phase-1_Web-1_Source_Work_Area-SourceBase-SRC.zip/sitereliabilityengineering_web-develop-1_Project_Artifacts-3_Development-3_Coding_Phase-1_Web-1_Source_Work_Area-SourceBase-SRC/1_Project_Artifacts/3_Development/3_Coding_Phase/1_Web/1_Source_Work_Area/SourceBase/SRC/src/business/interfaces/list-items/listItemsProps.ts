type ListItem = {
  key: string;
  item: React.ReactNode;
};

export type ListItemsProps = {
  wrapperClass?: string;
  listItemClass?: string;
  items: ListItem[];
};
