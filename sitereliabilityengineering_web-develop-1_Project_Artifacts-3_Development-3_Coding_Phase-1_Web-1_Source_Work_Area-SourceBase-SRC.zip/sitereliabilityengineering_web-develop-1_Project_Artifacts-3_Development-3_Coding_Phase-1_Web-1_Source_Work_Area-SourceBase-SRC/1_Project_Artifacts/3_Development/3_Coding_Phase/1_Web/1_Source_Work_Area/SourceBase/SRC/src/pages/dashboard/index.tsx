import type {
  NextPage,
  GetServerSideProps,
  InferGetServerSidePropsType
} from 'next';
import { serverSideTranslations } from 'next-i18next/serverSideTranslations';
import { Dashboard } from '@business/workflows/ComponentViews';
import type { PageProps } from '@business/interfaces/page';

const DashboardPage: NextPage = (
  _props: InferGetServerSidePropsType<typeof getServerSideProps>
) => <Dashboard />;

export const getServerSideProps: GetServerSideProps<PageProps> = async ({
  locale
}) => ({
  props: {
    ...(await serverSideTranslations(locale ?? 'en', ['common']))
  }
});

export default DashboardPage;
