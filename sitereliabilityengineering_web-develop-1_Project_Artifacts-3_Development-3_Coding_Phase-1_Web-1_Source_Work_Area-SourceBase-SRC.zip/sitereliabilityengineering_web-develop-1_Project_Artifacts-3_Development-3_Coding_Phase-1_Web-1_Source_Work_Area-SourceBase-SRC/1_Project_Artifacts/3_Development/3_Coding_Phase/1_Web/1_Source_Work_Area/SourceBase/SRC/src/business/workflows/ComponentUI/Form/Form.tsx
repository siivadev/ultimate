import { FC } from 'react';
import { useTranslation } from 'next-i18next';
import { generateField } from '@utils/helpers/lib/form';
import { FormProps } from '@business/interfaces/form';
import { Button } from '../Button';

export const Form: FC<FormProps> = ({
  fields,
  submitButtonText,
  submitButtonClass,
  handleSubmit,
  additionalButtons,
  children,
  register,
  errors
}) => {
  const { t } = useTranslation();

  return (
    <>
      <form onSubmit={handleSubmit} data-testid="form" className="w-full">
        {fields.map(field => {
          if (typeof field.columns !== 'undefined') {
            return (
              <div className={field.wrapperClass} key={field.key}>
                {field.columns.map((InputField, index) => {
                  return (
                    <div
                      className={`mt-5 w-${12 / field.columns.length}/12 ${
                        index !== field.columns.length - 1 ? 'mr-2' : ''
                      }`}
                      key={InputField.name}>
                      {generateField({
                        ...InputField,
                        ...register(InputField.name),
                        error: errors?.[InputField.name]?.message
                      })}
                    </div>
                  );
                })}
              </div>
            );
          } else {
            return (
              <div className="mt-5" key={field.name}>
                {generateField({
                  ...field,
                  ...register(field.name),
                  error: errors?.[field.name]?.message
                })}
              </div>
            );
          }
        })}
        {children}
        <Button
          label={t(submitButtonText)}
          className={submitButtonClass}
          type="submit"
        />
        {additionalButtons?.map(button => (
          <Button key={button.label} {...button} />
        ))}
      </form>
    </>
  );
};

Form.defaultProps = {
  submitButtonClass: 'mt-7 w-full !py-4'
};
