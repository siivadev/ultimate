import { FC } from 'react';
import { AuthenticationInfoProps } from '@business/interfaces/authentication-info';
import { Images } from '@business/assets/images';

export const AuthenticationInfo: FC<AuthenticationInfoProps> = ({
  title,
  description,
  image,
  titleContainer: TitleContainer,
  descriptionContainer: DescriptionContainer
}) => {
  return (
    <>
      <div className="md:w-6/12 w-full md:block hidden relative">
        <div
          data-testid="auth-info-image"
          className={`bg ${typeof image === 'undefined' ? 'bg-img-1' : ''}`}
          style={
            typeof image !== 'undefined'
              ? { backgroundImage: `url('${image}')` }
              : {}
          }>
          <div className="w-10/12 px-10 pt-7"></div>
          {/* <Footer /> */}
        </div>
      </div>
    </>
  );
};

AuthenticationInfo.defaultProps = {
  titleContainer: 'h3',
  descriptionContainer: 'p',
  image: Images.PreloginBanner.src
};
