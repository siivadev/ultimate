import type { ReactNode } from 'react';

export interface Badge {
  onClick?: () => void;
  label?: ReactNode;
}
