export * from './tabProps';
