export type SessionStateType = {
  token?: string | null;
  refreshToken?: string | null;
  firstLogin?: boolean;
  signUpType: string;
};
