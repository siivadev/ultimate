import React, { FC } from 'react';
import { SwitchProps } from '@business/interfaces/switch';
const getSizeClassName = (size: string) => {
  switch (size) {
    case 'small':
      return 'w-9 h-5 after:h-4 after:w-4';
    case 'large':
      return 'w-14 h-7 after:h-6 after:w-6';
    default:
      return 'w-12 h-6 after:h-5 after:w-5';
  }
};
const getColorClassName = (color: string) => {
  switch (color) {
    case 'primary':
      return 'peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:bg-blue-600';
    default:
      return 'peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:bg-blue-600';
  }
};

export const Switch: FC<SwitchProps> = ({
  color,
  size,
  label,
  controlled,
  checked,
  onChange,
  ...props
}) => {
  const handleInputChange = (event: any) => {
    if (controlled) {
      onChange(event.target.checked);
    }
  };
  return (
    <label className="relative inline-flex items-center cursor-pointer">
      <input
        data-testid="Switch"
        type="checkbox"
        {...props}
        checked={controlled ? checked : undefined}
        onChange={handleInputChange}
        className="sr-only peer"
      />
      <div
        data-testid="switch-button"
        className={`${getSizeClassName(size)} ${getColorClassName(
          color
        )} bg-gray-200 peer-focus:outline-none peer-focus:ring-0  rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full  after:transition-all dark:border-gray-600 `}></div>
      {label && (
        <span className="ml-3 text-sm text-gray-900 dark:text-gray-300">
          {label}
        </span>
      )}
    </label>
  );
};

Switch.defaultProps = {
  controlled: false
};
