import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { Switch } from './Switch';

describe('Switch', () => {
  test('renders component', () => {
    render(<Switch />);
    expect(screen.getByTestId('Switch')).toBeInTheDocument();
  });

  test('renders with label', () => {
    const label = 'Test label';
    const { getByText } = render(<Switch label={label} />);
    expect(getByText(label)).toBeInTheDocument();
  });

  test('calls onChange function when clicked', () => {
    const onChange = jest.fn();
    const { getByTestId } = render(
      <Switch controlled checked={false} onChange={onChange} />
    );
    fireEvent.click(getByTestId('Switch'));
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith(true);
  });

  test('does not call onChange function when clicked and controlled prop is false', () => {
    const onChange = jest.fn();
    const { getByTestId } = render(
      <Switch checked={false} onChange={onChange} />
    );
    fireEvent.click(getByTestId('Switch'));
    expect(onChange).not.toHaveBeenCalled();
  });

  test('renders small toggle button', () => {
    render(<Switch size="small" />);
    expect(screen.getByTestId('switch-button').className).toContain('w-9 h-5');
  });
  test('renders large toggle button', () => {
    render(<Switch size="large" />);
    expect(screen.getByTestId('switch-button').className).toContain('w-14 h-7');
  });
  test('renders primary toggle button', () => {
    render(<Switch color="primary" />);
    expect(screen.getByTestId('switch-button').className).toContain(
      'peer-checked:bg-blue-600'
    );
  });
});
