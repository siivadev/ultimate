import { addAlpha, makeLightenColorFromHex } from './colors';

describe('Color', () => {
  it('addAlpha function should be able add transparency', () => {
    const color = addAlpha('#000000', 0.8);
    expect(color).toContain('#000000CC');
  });
  it('makeLightenColorFromHex function should be able create a lighter version of the color', () => {
    const color = makeLightenColorFromHex('#161C24', 10);
    expect(color).toContain('#20262e');
  });
});
