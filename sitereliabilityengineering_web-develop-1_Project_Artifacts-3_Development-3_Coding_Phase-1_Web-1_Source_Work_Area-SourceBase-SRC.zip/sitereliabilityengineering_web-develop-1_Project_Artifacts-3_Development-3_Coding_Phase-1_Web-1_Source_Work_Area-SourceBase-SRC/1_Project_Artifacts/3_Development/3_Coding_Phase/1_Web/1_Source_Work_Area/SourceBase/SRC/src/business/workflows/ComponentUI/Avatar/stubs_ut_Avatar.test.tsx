import { render } from '@testing-library/react';
import Avatar from './Avatar';

describe('Avatar', () => {
  it('renders the avatar image', () => {
    const { getByRole } = render(
      <Avatar src="https://example.com/avatar.png" alt="Avatar" />
    );
    expect(getByRole('img')).toBeInTheDocument();
  });

  it('renders the placeholder with initials', () => {
    const { getByText } = render(<Avatar alt="Mary Don" />);
    expect(getByText('MD')).toBeInTheDocument();
  });

  it('renders the placeholder with custom text', () => {
    const { getByText } = render(<Avatar placeholder="No image" />);
    expect(getByText('No image')).toBeInTheDocument();
  });

  it('renders the rounded avatar', () => {
    const { container } = render(
      <Avatar
        src="https://example.com/avatar.png"
        alt="Avatar"
        rounded={true}
      />
    );
    expect(container.firstChild).toHaveClass('rounded-full');
  });

  it('renders the non-rounded avatar', () => {
    const { container } = render(
      <Avatar
        src="https://example.com/avatar.png"
        alt="Avatar"
        rounded={false}
      />
    );
    expect(container.firstChild).toHaveClass('rounded-none');
  });

  it('renders the avatar with custom size', () => {
    const { container } = render(
      <Avatar
        src="https://example.com/avatar.png"
        alt="Avatar"
        size="h-20 w-20"
      />
    );
    expect(container.firstChild).toHaveClass('h-20 w-20');
  });

  it('renders the avatar with presence', () => {
    const { container } = render(
      <Avatar
        src="https://example.com/avatar.png"
        alt="Avatar"
        presence={true}
      />
    );
    expect(container.querySelector('.bg-green-500')).toBeInTheDocument();
  });
});
