import type { ReactNode } from 'react';

export interface Button {
  onClick?: () => void;
  isDisabled?: boolean;
  href?: string;
  label?: ReactNode;
  startIcon?: ReactNode;
  endIcon?: ReactNode;
}
