export type Language = {
  name: string;
  lng: string;
};
