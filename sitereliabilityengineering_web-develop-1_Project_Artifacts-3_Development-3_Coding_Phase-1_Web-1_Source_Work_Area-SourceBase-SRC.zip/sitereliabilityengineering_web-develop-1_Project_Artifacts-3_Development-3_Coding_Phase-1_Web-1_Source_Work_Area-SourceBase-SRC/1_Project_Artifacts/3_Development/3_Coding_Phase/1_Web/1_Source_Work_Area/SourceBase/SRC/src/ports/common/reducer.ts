import { combineReducers } from 'redux';
import storage from 'redux-persist/lib/storage';
import { userApi } from '../internal-services/user/userApi';
import { sessionStateSlice } from './sessionStateSlice';
import { sessionSignUpSlice } from './signUpStateSlice';

const rootPersistConfig = {
  key: 'root',
  storage,
  keyPrefix: 'redux-'
};

const rootReducer = combineReducers({
  [userApi.reducerPath]: userApi.reducer,
  [sessionStateSlice.name]: sessionStateSlice.reducer,
  [sessionSignUpSlice.name]: sessionSignUpSlice.reducer
});

export { rootPersistConfig, rootReducer };
