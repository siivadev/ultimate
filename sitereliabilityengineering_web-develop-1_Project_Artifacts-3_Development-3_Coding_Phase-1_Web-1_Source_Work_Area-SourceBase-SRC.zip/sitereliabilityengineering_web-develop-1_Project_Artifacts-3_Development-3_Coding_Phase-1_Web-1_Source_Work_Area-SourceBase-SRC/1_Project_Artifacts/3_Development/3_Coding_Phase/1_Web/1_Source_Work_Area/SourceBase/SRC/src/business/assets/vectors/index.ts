/* eslint-disable global-require */

import AlertCheck from './alert-check.svg';
import AlertError from './alert-error.svg';
import AlertInfo from './alert-info.svg';
import AlertWarning from './alert-warning.svg';
import ArrowDownIcon from './arrow-down-icon.svg';
import CalendarIcon from './calendar-icon.svg';
import EditIcon from './edit-icon.svg';
import EmailIcon from './email-icon.svg';
import ExcelIcon from './excel-icon.svg';
import InfoIcon from './info-icon.svg';
import LocationIcon from './location-icon.svg';
import Logo from './logo.svg';
import PasswordIcon from './password-icon.svg';
import PeopleOrganizationIcon from './people-organization-icon.svg';
import PhoneIcon from './phone-icon.svg';
import SearchIcon from './search-icon.svg';
import SupportIcon from './support-icon.svg';
import TableViewIcon from './table-view-icon.svg';
import UploadIcon from './upload-icon.svg';
import VisibilityOff from './visibility-off.svg';

export const SVGAssets = {
  AlertCheck,
  AlertError,
  AlertInfo,
  AlertWarning,
  ArrowDownIcon,
  CalendarIcon,
  EditIcon,
  EmailIcon,
  ExcelIcon,
  InfoIcon,
  LocationIcon,
  Logo,
  PasswordIcon,
  PeopleOrganizationIcon,
  PhoneIcon,
  SearchIcon,
  SupportIcon,
  TableViewIcon,
  UploadIcon,
  VisibilityOff
};
