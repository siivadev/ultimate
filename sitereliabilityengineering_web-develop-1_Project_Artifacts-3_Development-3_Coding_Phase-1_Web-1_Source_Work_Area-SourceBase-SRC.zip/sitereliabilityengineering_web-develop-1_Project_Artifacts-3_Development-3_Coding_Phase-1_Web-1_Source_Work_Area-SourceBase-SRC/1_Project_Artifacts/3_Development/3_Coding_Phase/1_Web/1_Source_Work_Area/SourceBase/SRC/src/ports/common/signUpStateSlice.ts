import { createSlice } from '@reduxjs/toolkit';
import { SessionSignUpType } from '@business/entities/session/sessionSignUp';
import type { RootState } from './store';

const initialState: SessionSignUpType = {
  name: '',
  mobileNumber: '',
  emailId: '',
  password: ''
};

export const sessionSignUpSlice = createSlice({
  name: 'signUpStateSlice',
  initialState,
  reducers: {
    setSignUpDetails: (state, action) => {
      state.name = action.payload.name;
      state.mobileNumber = action.payload.mobileNumber;
      state.emailId = action.payload.emailId;
      state.password = action.payload.password;
    },
    resetSessionSignUpState: () => {
      return initialState;
    }
  }
});

export const { setSignUpDetails, resetSessionSignUpState } =
  sessionSignUpSlice.actions;

export const getSignUpState = (state: RootState) => state.signUpStateSlice;
