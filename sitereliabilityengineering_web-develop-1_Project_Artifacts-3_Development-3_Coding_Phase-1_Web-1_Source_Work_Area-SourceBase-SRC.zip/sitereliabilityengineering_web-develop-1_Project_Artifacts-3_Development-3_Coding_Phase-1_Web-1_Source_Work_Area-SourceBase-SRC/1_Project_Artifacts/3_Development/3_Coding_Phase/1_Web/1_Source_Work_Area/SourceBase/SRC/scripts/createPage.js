const fs = require('fs');
const args = process.argv;

const jsUcWord = name =>
  name
    .trim()
    .replace(/\s\s+/g, ' ')
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join('');

const jsHyphenate = name =>
  name.toLowerCase().trim().replace(/\s\s+/g, ' ').split(' ').join('-');

const featureDir = args[2];
const feature = jsUcWord(featureDir);

const generatePageComponent = () => {
  const pageComponentRootDir = `./src/business/workflows/componentViews`;
  const pageComponentDir = `${pageComponentRootDir}/${feature}`;
  if (!fs.existsSync(pageComponentDir)) {
    fs.mkdirSync(pageComponentDir);
  }

  const indexFile = `${pageComponentDir}/index.ts`;
  const indexFileContent = `export * from "./${feature}";
  `;
  fs.writeFileSync(indexFile, indexFileContent, 'utf8');

  const pageComponentFile = `${pageComponentDir}/${feature}.tsx`;
  const pageComponentContent = `import { useTranslation } from 'next-i18next';
    
export function ${feature}() {
  const {t} = useTranslation();
  return (
    <>
      <div data-testid="${jsHyphenate(featureDir)}-page">
        {t("hello")}
      </div>
    </>
  );
}
`;
  fs.writeFileSync(pageComponentFile, pageComponentContent, 'utf8');

  const pageComponentStubFile = `${pageComponentDir}/stubs_ut_${feature}.test.tsx`;
  const pageComponentStubContent = `import { render, screen } from '@testing-library/react';
import { ${feature} } from './${feature}';
  
function ${feature}Component() {
  return (
    <ComponentProvider>
      <${feature} />
    </ComponentProvider>
  );
}

describe('${featureDir.toUpperCase()} SCREEN', () => {
  test('is rendered', async () => {
    render(<${feature}Component />);
    expect(screen.getByTestId('${jsHyphenate(
      featureDir,
    )}-page')).toBeInTheDocument();
  });
});
`;
  fs.writeFileSync(pageComponentStubFile, pageComponentStubContent, 'utf8');

  fs.appendFile(
    `${pageComponentRootDir}/index.ts`,
    `\nexport * from "./${feature}";`,
    function (err) {
      if (err) {
        console.log('error', err);
      }
    },
  );
};

const generateRoute = () => {
  const routeDir = `./src/pages/${jsHyphenate(featureDir)}`;
  let proceed = true;
  if (!fs.existsSync(routeDir)) {
    fs.mkdirSync(routeDir);
  } else {
    console.log("The page already exist");
    proceed = false;
  }
  if (proceed) {
    const indexFile = `${routeDir}/index.tsx`;
    const content = `import type {
  NextPage,
  GetServerSideProps,
  InferGetServerSidePropsType
} from 'next';
import { serverSideTranslations } from 'next-i18next/serverSideTranslations';
import { ${feature} } from '@business/workflows/ComponentViews';
import type { PageProps } from '@business/interfaces/page';
const ${feature}Page: NextPage = (
  _props: InferGetServerSidePropsType<typeof getServerSideProps>
) => <${feature} />;

export const getServerSideProps: GetServerSideProps<PageProps> = async ({
  locale
}) => ({
  props: {
    ...(await serverSideTranslations(locale ?? 'en', ['common']))
  }
});

export default ${feature}Page;
`;
    fs.writeFileSync(indexFile, content, 'utf8');
    generatePageComponent();
  }
};

generateRoute();
