import { render, screen } from '@testing-library/react';
import { Provider } from 'react-redux';
import { SectionProps } from '@business/interfaces/section';
import { store } from '@ports/common/store';
import { Section } from './Section';

function SectionComponent(props: SectionProps) {
  const { title, children } = props;
  return (
    <Provider store={store}>
      <Section title={title}>{children}</Section>
    </Provider>
  );
}

describe('SECTION', () => {
  test('is rendered', async () => {
    render(<SectionComponent title="section" />);
    expect(screen.getByTestId('section').textContent).toContain('section');
  });
  test('is rendered with title', async () => {
    render(<SectionComponent title="section" />);
    expect(screen.getByTestId('sectionTitle').textContent).toContain('section');
  });
  test('is rendered and has children', async () => {
    render(<SectionComponent title="section">Children</SectionComponent>);
    expect(screen.getByTestId('sectionHasChildren').textContent).toContain(
      'Children'
    );
  });
});
