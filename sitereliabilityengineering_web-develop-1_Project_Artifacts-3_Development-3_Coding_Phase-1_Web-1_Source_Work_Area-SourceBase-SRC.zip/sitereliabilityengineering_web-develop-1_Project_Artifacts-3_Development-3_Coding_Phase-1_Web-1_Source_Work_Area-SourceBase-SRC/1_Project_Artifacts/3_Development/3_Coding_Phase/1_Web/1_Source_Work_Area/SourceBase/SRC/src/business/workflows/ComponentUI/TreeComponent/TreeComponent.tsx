import React from 'react';

interface TreeNode {
  id: number;
  label: string;
  children: TreeNode[];
}

interface TreeProps {
  data: TreeNode[];
}

const TreeNodeComponent: React.FC<{ node: TreeNode; level: number }> = ({
  node,
  level
}) => {
  const [isExpanded, setIsExpanded] = React.useState(false);

  const hasChildren = node.children.length > 0;

  const toggleExpand = React.useCallback(() => {
    setIsExpanded(!isExpanded);
  }, [isExpanded]);

  const taskTrigger = React.useCallback(() => {
    console.log('last child click');
  }, []);

  return (
    <div className={`pl-${level * 4}`}>
      <div className="flex items-center cursor-pointer" onClick={toggleExpand}>
        {hasChildren ? (
          <>
            <span className="mr-1">{isExpanded ? '👇' : '👉'}</span>
            <span className="text-lg font-medium">{node.label}</span>
          </>
        ) : (
          <span className="text-blue-500 cursor-pointer" onClick={taskTrigger}>
            {node.label}
          </span>
        )}
      </div>
      {hasChildren && isExpanded && (
        <div className="pl-4">
          {node.children.map(childNode => (
            <TreeNodeComponent
              key={childNode.id}
              node={childNode}
              level={level + 1}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export const TreeComponent: React.FC<TreeProps> = ({ data }) => {
  return (
    <div>
      {data.map(node => (
        <div key={node.id}>
          <TreeNodeComponent node={node} level={0} />
        </div>
      ))}
    </div>
  );
};

export default TreeComponent;
