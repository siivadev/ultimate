const fs = require('fs');
const path = require('path');

function copyFile(src, dest) {
  // Read the source file
  const source = fs.createReadStream(src);

  // Create the destination file
  const destination = fs.createWriteStream(dest);

  // Copy the contents from source to destination
  source.pipe(destination);

  // Return a Promise that resolves when the copying is done
  return new Promise((resolve, reject) => {
    source.on('end', resolve);
    source.on('error', reject);
  });
}

function copyFolder(src, dest) {
  // Make sure the destination folder exists
  fs.mkdirSync(dest, { recursive: true });

  // Read the contents of the source folder
  const entries = fs.readdirSync(src, { withFileTypes: true });

  // Copy each entry (file or folder) in the source folder
  entries.forEach(entry => {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);

    if (entry.isFile() && entry.name !== 'i18n.ts') {
      copyFile(srcPath, destPath);
    } else if (entry.isDirectory()) {
      copyFolder(srcPath, destPath);
    }
  });
}

const srcPath = 'src/business/localization/language';
const destPath = 'public/locales';
copyFolder(`${srcPath}`, `${destPath}`);
