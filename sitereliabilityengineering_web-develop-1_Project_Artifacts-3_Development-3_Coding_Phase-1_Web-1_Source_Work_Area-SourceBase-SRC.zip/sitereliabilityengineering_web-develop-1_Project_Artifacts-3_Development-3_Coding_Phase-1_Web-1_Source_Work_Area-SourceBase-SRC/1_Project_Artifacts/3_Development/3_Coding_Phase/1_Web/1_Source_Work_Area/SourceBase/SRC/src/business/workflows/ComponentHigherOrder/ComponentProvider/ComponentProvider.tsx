import React from 'react';
import { Provider } from 'react-redux';
import { ComponentProviderProps } from '@business/interfaces/component-provider';
import { store } from '@ports/common/store';
import { AuthGuard } from '../AuthGuard';

/*
 * This component is used as wrapper to generate unit tests
 */
export function ComponentProvider({ children }: ComponentProviderProps) {
  return (
    <Provider store={store}>
      <AuthGuard>{children}</AuthGuard>
    </Provider>
  );
}
