import {
  setSignUpType,
  resetSessionState,
  sessionStateSlice
} from './sessionStateSlice';

describe('sessionStateSlice', () => {
  it('should set the sign up type', () => {
    const initialState = { signUpType: 'forMyTeam' };
    const action = setSignUpType('forMe');
    const newState = sessionStateSlice.reducer(initialState, action);
    expect(newState.signUpType).toEqual('forMe');
  });

  it('should reset the session state', () => {
    const initialState = {
      signUpType: 'forMe',
      token: 'abcd1234',
      refreshToken: 'efgh5678',
      firstLogin: false
    };
    const action = resetSessionState();
    const newState = sessionStateSlice.reducer(initialState, action);
    expect(newState).toEqual({ signUpType: 'forMyTeam' });
  });
});
