import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import RadioGroup from './RadioGroup';

describe('RadioGroup', () => {
  const options = [
    { label: 'Option 1', value: 'option1' },
    { label: 'Option 2', value: 'option2' },
    { label: 'Option 3', value: 'option3', disabled: true }
  ];

  it('renders radio buttons with correct labels and values', () => {
    const { getByLabelText } = render(
      <RadioGroup size="medium" color="blue" options={options} />
    );
    options.forEach(option => {
      const radio = getByLabelText(option.label);
      expect(radio).toBeInTheDocument();
      expect(radio.getAttribute('value')).toBe(option.value);
    });
  });

  it('calls onChange callback when radio button is selected', () => {
    const mockOnChange = jest.fn();
    const { getByLabelText } = render(
      <RadioGroup
        size="medium"
        color="blue"
        options={options}
        onChange={mockOnChange}
      />
    );
    const radio = getByLabelText('Option 2');
    fireEvent.click(radio);
    expect(mockOnChange).toHaveBeenCalledWith('option2');
  });

  it('disables the radio button if the "disabled" property is true', () => {
    const { getByLabelText } = render(
      <RadioGroup size="medium" color="blue" options={options} />
    );
    const disabledRadio = getByLabelText('Option 3');
    expect(disabledRadio).toBeDisabled();
  });
});
