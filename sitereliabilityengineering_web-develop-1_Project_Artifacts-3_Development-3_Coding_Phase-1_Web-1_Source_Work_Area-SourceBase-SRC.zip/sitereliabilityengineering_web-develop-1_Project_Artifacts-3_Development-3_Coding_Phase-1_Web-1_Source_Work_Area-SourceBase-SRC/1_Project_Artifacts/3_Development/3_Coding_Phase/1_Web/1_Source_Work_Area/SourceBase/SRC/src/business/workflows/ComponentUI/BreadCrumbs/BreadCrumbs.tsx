import React from 'react';
import { BreadcrumbsProps } from '@business/interfaces/bread-crumbs';

const Breadcrumbs: React.FC<BreadcrumbsProps> = ({
  items,
  separator = '>'
}) => {
  return (
    <div data-testid="bread-Crumb-tag">
      {items.map((item, index) => (
        <span key={item.link}>
          {index > 0 && (
            <span className="breadcrumb-separator">{separator}</span>
          )}
          <a
            href={item.link}
            className={`breadcrumb-item ${
              index === items.length - 1 ? 'active' : ''
            }`}
            aria-current={index === items.length - 1 ? 'page' : undefined}>
            {item.icon && <span className="me-1">{item.icon}</span>}
            {item.label}
          </a>
        </span>
      ))}
    </div>
  );
};

export default Breadcrumbs;
