import React from 'react';
import { render, screen } from '@testing-library/react';
import ListItems from './ListItems';

describe('ListItems component', () => {
  const items = [
    { key: '1', item: <div>Item 1</div> },
    { key: '2', item: <div>Item 2</div> },
    { key: '3', item: <div>Item 3</div> }
  ];

  it('should render a list with correct number of items', () => {
    render(<ListItems items={items} />);

    const listItems = screen.getAllByRole('listitem');
    expect(listItems).toHaveLength(items.length);
  });

  it('should render items with correct content', () => {
    render(<ListItems items={items} />);

    const listItems = screen.getAllByRole('listitem');
    listItems.forEach((item, index) => {
      expect(item).toHaveTextContent(`Item ${index + 1}`);
    });
  });

  it('should apply wrapperClass to ul element', () => {
    const wrapperClass = 'test-wrapper';
    render(<ListItems items={items} wrapperClass={wrapperClass} />);

    const list = screen.getByRole('list');
    expect(list).toHaveClass(wrapperClass);
  });

  it('should apply listItemClass to li elements', () => {
    const listItemClass = 'test-item';
    render(<ListItems items={items} listItemClass={listItemClass} />);

    const listItems = screen.getAllByRole('listitem');
    listItems.forEach(item => {
      expect(item).toHaveClass(listItemClass);
    });
  });
});
