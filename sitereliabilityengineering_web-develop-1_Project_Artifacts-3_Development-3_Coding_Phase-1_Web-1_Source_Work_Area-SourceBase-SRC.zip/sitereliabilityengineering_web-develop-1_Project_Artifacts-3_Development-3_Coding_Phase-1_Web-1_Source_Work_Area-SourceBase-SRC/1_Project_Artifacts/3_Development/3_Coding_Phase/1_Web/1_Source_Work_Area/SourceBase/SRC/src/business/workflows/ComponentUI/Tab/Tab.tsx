import { FC } from 'react';
import { TabProps } from '@business/interfaces/tab';

export const Tab: FC<TabProps> = ({
  color,
  disabled,
  size,
  startIcon,
  onClick,
  wrapperClass,
  content,
  tabs,
  activeTab,
  ...props
}) => {
  return (
    <>
      <div className="tabs">
        {tabs?.map((tab, index: number) => (
          <a
            key={index}
            className={`"tab tab-bordered${
              activeTab === index ? 'tab-active' : ''
            }"`}
            onClick={onClick}>
            {tab.value}
          </a>
        ))}
      </div>
      <div className="tab-content">
        {tabs?.map((tab, index) => (
          <div
            key={index}
            className={`tab-pane ${activeTab === index ? 'active' : ''}`}>
            {tab.content}
          </div>
        ))}
      </div>
    </>
  );
};

Tab.defaultProps = {};
