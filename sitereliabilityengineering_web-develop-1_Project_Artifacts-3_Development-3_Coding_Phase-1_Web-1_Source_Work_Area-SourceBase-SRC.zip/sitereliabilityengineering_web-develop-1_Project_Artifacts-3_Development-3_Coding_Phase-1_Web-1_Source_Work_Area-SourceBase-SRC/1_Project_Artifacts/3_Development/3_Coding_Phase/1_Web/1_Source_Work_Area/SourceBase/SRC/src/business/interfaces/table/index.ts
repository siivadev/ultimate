export * from './tableProps';
