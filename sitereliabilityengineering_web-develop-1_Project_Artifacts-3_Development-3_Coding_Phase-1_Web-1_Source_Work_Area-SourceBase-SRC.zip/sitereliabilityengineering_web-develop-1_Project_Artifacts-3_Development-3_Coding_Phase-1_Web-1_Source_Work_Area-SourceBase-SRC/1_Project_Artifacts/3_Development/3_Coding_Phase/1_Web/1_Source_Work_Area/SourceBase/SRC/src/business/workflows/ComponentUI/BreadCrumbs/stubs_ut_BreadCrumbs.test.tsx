import { render, screen } from '@testing-library/react';
import Breadcrumbs from './BreadCrumbs';

const breadcrumbItems = [
  { label: 'Home', link: '/' },
  { label: 'Documents', link: '/documents' },
  { label: 'Add documents', link: '/add/documents' }
];

describe('Breadcrumbs component', () => {
  it('renders the breadcrumbs with the correct items and separator', () => {
    render(<Breadcrumbs items={breadcrumbItems} separator="|" />);

    const breadcrumbList = screen.getByTestId('bread-Crumb-tag');
    expect(breadcrumbList).toBeInTheDocument();

    const breadcrumbLinks = breadcrumbList.querySelectorAll('a');
    expect(breadcrumbLinks).toHaveLength(3);

    expect(breadcrumbLinks[0]).toHaveTextContent('Home');
    expect(breadcrumbLinks[0]).toHaveAttribute('href', '/');

    expect(breadcrumbLinks[1]).toHaveTextContent('Documents');
    expect(breadcrumbLinks[1]).toHaveAttribute('href', '/documents');

    expect(breadcrumbLinks[2]).toHaveTextContent('Add documents');
    expect(breadcrumbLinks[2]).toHaveAttribute('href', '/add/documents');

    const breadcrumbSeparators = breadcrumbList.querySelectorAll(
      '.breadcrumb-separator'
    );
    expect(breadcrumbSeparators).toHaveLength(2);
    expect(breadcrumbSeparators[0]).toHaveTextContent('|');
    expect(breadcrumbSeparators[1]).toHaveTextContent('|');
  });

  it('renders the active breadcrumb with the correct aria-current attribute', () => {
    render(<Breadcrumbs items={breadcrumbItems} separator="|" />);

    const breadcrumbLinks = screen.getAllByRole('link');
    expect(breadcrumbLinks[2]).toHaveAttribute('aria-current', 'page');
  });
});
