import { FC } from 'react';
import { RadialProgressProps } from '@business/interfaces/radial-progress';

export const RadialProgress: FC<RadialProgressProps> = ({
  color = 'primary',
  size = 'medium',
  label = '',
  progress = 0,
  height = 100,
  wrapperClass = '',
  className = '',
  shape = 'circle'
}) => {
  const radius = height / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <div
      className={`${className} ${wrapperClass}`}
      style={{ width: height, height }}
      role="progressbar">
      <svg
        className={`radial-progress ${color} ${size} ${shape}`}
        viewBox={`0 0 ${height} ${height}`}>
        {shape === 'circle' ? (
          <circle
            className="radial-progress__bg"
            cx={radius}
            cy={radius}
            r={radius * 0.9}
          />
        ) : (
          <ellipse
            className="radial-progress__bg"
            cx={radius}
            cy={radius}
            rx={radius * 0.9}
            ry={radius * 0.5}
          />
        )}
        <circle
          className="radial-progress__fill"
          cx={radius}
          cy={radius}
          r={radius * 0.9}
          strokeDasharray={`${circumference} ${circumference}`}
          strokeDashoffset={strokeDashoffset}
        />
      </svg>
      {label && (
        <div className="radial-progress__label">{`${progress}% ${label}`}</div>
      )}
    </div>
  );
};
