const fs = require('fs');
const dotenv = require('dotenv');
const prettier = require('prettier');
const options = prettier.resolveConfig.sync(process.cwd());
const basePath = 'src/utils/constants';
if (!fs.existsSync(basePath)) {
  fs.mkdirSync(basePath);
}

const args = process.argv;

const envFile = args[2];

const generateEnv = () => {
  // Read the contents of the .env file
  const env = fs.readFileSync(envFile);

  // Parse the contents into an object
  const envObj = dotenv.parse(env);
  const envContent = `export const dotenv=${JSON.stringify(envObj)}
`;
  const filePath = basePath + '/env.ts';
  const formattedContent = prettier.format(envContent, {
    ...options,
    filepath: filePath
  });
  fs.writeFileSync(filePath, formattedContent, 'utf8');
};

generateEnv();
