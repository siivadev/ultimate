export const dotenv = {
  API_BASE_URL: 'http://localhost:5000',
  FRONTEND_BASE_URL: 'localhost:4200',
  IS_ADMIN: 'false',
  PORT: '3000'
};
