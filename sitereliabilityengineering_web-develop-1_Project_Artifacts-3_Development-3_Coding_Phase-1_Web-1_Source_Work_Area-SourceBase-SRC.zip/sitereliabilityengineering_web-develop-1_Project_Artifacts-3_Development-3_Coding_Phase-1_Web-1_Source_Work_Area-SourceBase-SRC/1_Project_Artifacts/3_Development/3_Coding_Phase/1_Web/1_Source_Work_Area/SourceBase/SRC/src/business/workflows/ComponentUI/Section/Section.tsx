import { SectionProps } from '@business/interfaces/section';

export function Section({ children, title }: SectionProps): JSX.Element {
  return (
    <div className="my-5" data-testid="section">
      <span data-testid="sectionTitle" className="text-xl font-medium">
        {title}
      </span>
      <div data-testid="sectionHasChildren" className="text-base mt-2 mb-3">
        {children}
      </div>
    </div>
  );
}
