import { createSlice } from '@reduxjs/toolkit';
import { SessionStateType } from '@business/entities/session';
import type { RootState } from './store';

const initialState: SessionStateType = {
  signUpType: 'forMyTeam'
};

export const sessionStateSlice = createSlice({
  name: 'sessionStateSlice',
  initialState,
  reducers: {
    setSignUpType: (state, action) => {
      state.signUpType = action.payload;
    },
    setToken: (state, action) => {
      state.token = action.payload.token;
      state.refreshToken = action.payload.refreshToken;
    },
    setFirstLogin: (state, action) => {
      state.firstLogin = action.payload;
    },
    resetSessionState: () => {
      return initialState;
    }
  }
});

export const { setSignUpType, setToken, setFirstLogin, resetSessionState } =
  sessionStateSlice.actions;
export const getSignUpType = (state: RootState) =>
  state.sessionStateSlice.signUpType;
export const getToken = (state: RootState) => state.sessionStateSlice?.token;
export const getRefreshToken = (state: RootState) =>
  state.sessionStateSlice?.refreshToken;
export const getFirstLogin = (state: RootState) =>
  state.sessionStateSlice?.firstLogin;
