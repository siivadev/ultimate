import type { PropsWithChildren } from 'react';

export type SectionProps = PropsWithChildren<{
  title: string;
}>;
