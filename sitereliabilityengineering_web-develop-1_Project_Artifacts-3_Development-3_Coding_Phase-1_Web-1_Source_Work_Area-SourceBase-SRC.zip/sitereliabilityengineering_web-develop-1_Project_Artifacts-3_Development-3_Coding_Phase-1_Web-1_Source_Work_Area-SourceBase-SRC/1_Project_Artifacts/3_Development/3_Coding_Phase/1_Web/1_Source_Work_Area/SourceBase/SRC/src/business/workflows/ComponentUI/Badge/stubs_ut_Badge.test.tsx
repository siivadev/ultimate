import { render, fireEvent } from '@testing-library/react';
import { Badge } from './Badge';

describe('Badge', () => {
  const defaultProps = {
    label: 'Badge label',
    onClick: jest.fn()
  };

  it('renders with default props', () => {
    const { getByTestId } = render(<Badge {...defaultProps} />);
    const badge = getByTestId('badge-tag');
    expect(badge).toBeInTheDocument();
    expect(badge).toHaveClass('button button-primary');
    expect(badge).toHaveTextContent('Badge label');
  });

  it('renders with custom props', () => {
    const { getByTestId } = render(
      <Badge
        {...defaultProps}
        btnStyle="secondary"
        className="custom-class"
        size="large"
        fullWidth
      />
    );
    const badge = getByTestId('badge-tag');
    expect(badge).toBeInTheDocument();
    expect(badge).toHaveClass(
      'button button-secondary custom-class w-full text-lg py-3'
    );
    expect(badge).toHaveTextContent('Badge label');
  });

  it('calls onClick when clicked', () => {
    const { getByTestId } = render(<Badge {...defaultProps} />);
    const badge = getByTestId('badge-tag');
    fireEvent.click(badge);
    expect(defaultProps.onClick).toHaveBeenCalledTimes(1);
  });
});
