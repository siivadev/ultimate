/* eslint no-use-before-define: 0 */
const fs = require('fs');
const args = process.argv;
const basePath = 'src/';

const folderNames = path => {
  let array = fs
    .readdirSync(basePath + path, {withFileTypes: true})
    .filter(dirent => dirent.isDirectory())
    .map(dirent => dirent.name);

  return Array.from(new Set(array));
};

const getDestinationPath = destination => {
  switch (destination) {
    case 'ui':
      return 'business/workflows/ComponentUI';
    case 'higherOrder':
      return 'business/workflows/ComponentHigherOrder';
    case 'validations':
      return 'utils/validations';
    default:
      return 'business/workflows/ComponentViews';
  }
};

const generate = () => {
  const destination = getDestinationPath(args[2]);
  const components = folderNames(destination)
    .map(name => {
      return `export * from './${name}';`;
    })
    .join('\n');

  const fileContentString = `${components.length !== 0 && components}
`;

  fs.writeFileSync(
    basePath + destination + '/index.ts',
    fileContentString,
    'utf8',
  );
};
generate();
