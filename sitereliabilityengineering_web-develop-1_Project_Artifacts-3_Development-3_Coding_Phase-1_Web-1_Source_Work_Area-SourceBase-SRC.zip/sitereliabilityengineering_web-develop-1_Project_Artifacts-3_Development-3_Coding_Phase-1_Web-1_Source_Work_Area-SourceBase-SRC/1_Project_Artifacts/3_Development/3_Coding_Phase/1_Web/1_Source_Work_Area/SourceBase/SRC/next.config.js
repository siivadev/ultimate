/** @type {import('next').NextConfig} */
const dotenv = require('dotenv');
const withPWA = require('next-pwa')({
  register: true,
  dest: 'public'
});
const { i18n } = require('./next-i18next.config');
dotenv.config();

const nextConfig = {
  i18n,
  reactStrictMode: true,
  webpack(config) {
    config.module.rules.push({
      test: /\.svg$/i,
      issuer: /\.[jt]sx?$/,
      use: ['@svgr/webpack']
    });

    return config;
  },
  distDir: 'dist'
};

module.exports = withPWA(nextConfig);
