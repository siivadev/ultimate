export interface RadioGroupProps {
  size: 'small' | 'medium' | 'large';
  color: string;
  options: {
    label: string;
    value: string;
    disabled?: boolean;
  }[];
  onChange?: (value: string) => void;
}
