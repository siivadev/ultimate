import { FC } from 'react';
import Link from 'next/link';
import { ButtonProps } from '@business/interfaces/button';

const getButtonClassName = (btnStyle: string) => {
  switch (btnStyle) {
    case 'primary':
      return `button button-primary`;
    case 'secondary':
      return `button button-secondary`;
    case 'default-outline':
      return `button button-transparent`;
    default:
      return 'text-link';
  }
};

export const Button: FC<ButtonProps> = ({
  type,
  btnStyle,
  className,
  onClick,
  isDisabled,
  size,
  fullWidth,
  href,
  label,
  startIcon,
  endIcon,
  loading,
  children
}) => {
  const finalClassName = `${getButtonClassName(btnStyle)} ${className} ${
    fullWidth ? 'w-full' : ''
  } ${
    size === 'small' ? 'text-sm py-1' : size === 'large' ? 'text-lg py-3' : ''
  } ${isDisabled ? 'opacity-50 cursor-not-allowed' : ''}`;
  return (
    <>
      {typeof href !== 'undefined' ? (
        <Link
          href={href}
          onClick={onClick}
          className={finalClassName}
          data-testid="anchor-tag">
          {startIcon && !loading && (
            <span className="icon start-icon">{startIcon}</span>
          )}
          {loading && <div className="loader" data-testid="button-loader" />}
          {label}
          {children}
          {endIcon && !loading && (
            <span className="icon end-icon">{endIcon}</span>
          )}
        </Link>
      ) : (
        <button
          data-testid="button-tag"
          type={type}
          className={finalClassName}
          onClick={onClick}
          disabled={isDisabled}>
          {startIcon && !loading && (
            <span className="icon start-icon">{startIcon}</span>
          )}
          {loading && <div className="loader" data-testid="button-loader" />}
          {label}
          {children}
          {endIcon && !loading && (
            <span className="icon end-icon">{endIcon}</span>
          )}
        </button>
      )}
    </>
  );
};

Button.defaultProps = {
  type: 'button',
  btnStyle: 'primary',
  className: ''
};
