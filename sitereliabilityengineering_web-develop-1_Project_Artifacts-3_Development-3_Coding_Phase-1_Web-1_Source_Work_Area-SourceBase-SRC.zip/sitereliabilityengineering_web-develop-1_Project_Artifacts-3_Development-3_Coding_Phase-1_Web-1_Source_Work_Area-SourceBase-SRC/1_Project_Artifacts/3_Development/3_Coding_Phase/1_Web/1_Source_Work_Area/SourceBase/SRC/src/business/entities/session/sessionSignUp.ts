export interface SessionSignUpType {
  name?: string;
  mobileNumber?: string;
  emailId?: string;
  password?: string;
}
