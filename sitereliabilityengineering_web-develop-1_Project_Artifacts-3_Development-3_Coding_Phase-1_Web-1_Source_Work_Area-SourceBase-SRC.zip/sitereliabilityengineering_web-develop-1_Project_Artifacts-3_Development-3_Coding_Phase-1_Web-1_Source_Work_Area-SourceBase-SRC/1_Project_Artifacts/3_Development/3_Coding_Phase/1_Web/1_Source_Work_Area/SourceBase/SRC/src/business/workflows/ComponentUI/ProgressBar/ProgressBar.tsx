import { FC } from 'react';
import { ProgressBarProps } from '@business/interfaces/progress-bar';

export const ProgressBar: FC<ProgressBarProps> = ({ ...props }) => {
  return (
    <>
      <div className={props.className}>
        <div className={props.wrapperClass}>
          <span>{`${props.progress}%`}</span>
        </div>
      </div>
    </>
  );
};
