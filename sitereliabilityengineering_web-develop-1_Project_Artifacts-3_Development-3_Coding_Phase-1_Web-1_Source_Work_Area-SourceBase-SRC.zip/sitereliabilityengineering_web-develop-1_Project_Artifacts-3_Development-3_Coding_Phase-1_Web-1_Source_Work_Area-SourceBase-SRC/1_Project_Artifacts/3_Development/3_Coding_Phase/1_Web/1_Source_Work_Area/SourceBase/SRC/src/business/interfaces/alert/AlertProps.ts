import { ReactElement, ReactNode } from 'react';
export interface AlertProps {
  type: string;
  heading: string;
  subHeading?: string | ReactElement;
  wrapperClass?: string;
  contentClass?: string;
  onClose?: () => void;
  isClosable?: boolean;
  isFocusable?: boolean;
  autoHide?: boolean;
  autoHideDuration?: number;
  onClick?: () => void;
  customLeftIcon?: ReactElement;
  customRightIcon?: ReactElement;
  children?: ReactNode;
}
