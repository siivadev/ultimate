from .models import Commit,ClocTable
from datetime import datetime
from django.db.models import F, Sum


class MysqlAdapter:
    def save_cloc_data(self, language, files, blank, comment, code):
        clocloc = ClocTable.objects.create(
            language=language,
            files=files,
            blank=blank,
            comment=comment,
            code=code
        )
        clocloc.save()
    def eachperson_productivity(self):
        commit_data = Commit.objects.all().values()
        return list(commit_data)
    def get_commit(self):
        commit_stats = Commit.objects.values('author').annotate(productivity=Sum(F('additions') - F('deletions')))
        print(commit_stats)
        stats_list = list(commit_stats)
        return stats_list
    def save_commit_data(self, commit_data):
        for commit in commit_data:
            commit_datetime = commit['date']
            commit_datetime_obj = datetime.strptime(commit_datetime, "%Y-%m-%dT%H:%M:%S.%f%z")
            date = commit_datetime_obj.strftime("%Y-%m-%d")
            time = commit_datetime_obj.strftime("%H:%M:%S")
            print(commit)
            Commit.objects.create(
                commit_id=commit['commit_id'],
                author=commit['author'],
                date=date,
                time=time,
                additions=commit['additions'],
                deletions=commit['deletions'],
                build_unique_refer_id=1,
                project_name="Technology"
            )