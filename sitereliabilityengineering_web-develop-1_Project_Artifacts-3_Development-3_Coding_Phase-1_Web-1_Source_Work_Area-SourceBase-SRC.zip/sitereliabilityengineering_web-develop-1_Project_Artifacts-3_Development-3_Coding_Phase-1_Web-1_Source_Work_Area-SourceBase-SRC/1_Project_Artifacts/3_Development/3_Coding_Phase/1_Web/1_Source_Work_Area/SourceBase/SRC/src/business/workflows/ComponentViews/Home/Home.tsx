import { useTranslation } from 'next-i18next';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useDispatch } from 'react-redux';
import { Form, AuthenticationInfo } from '@business/workflows/ComponentUI';
import { SVGAssets } from '@business/assets/vectors';
import { signInSchema } from '@utils/validations';
import type { FormFieldType } from '@business/interfaces/form';
import { setFirstLogin, setToken } from '@ports/common/sessionStateSlice';
interface SignInFormInput {
  emailId: string;
  password: string;
}

export function Home() {
  const { t } = useTranslation();
  const iconSizeClass = 'w-8 h-5';
  const dispatch = useDispatch();

  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm<SignInFormInput>({ resolver: yupResolver(signInSchema) });

  const fields: FormFieldType[] = [
    {
      label: t('Email'),
      name: 'emailId',
      type: 'text',
      startDecorator: <SVGAssets.EmailIcon className={iconSizeClass} />
    },
    {
      label: t('Password'),
      name: 'password',
      type: 'password',
      autoComplete: 'newpassword',
      startDecorator: <SVGAssets.PasswordIcon className={iconSizeClass} />
    }
  ];

  // const [Login] = useLoginMutation();
  const handleSubmitForm = (values: SignInFormInput) => {
    // const loginData = {
    //   userLogin: {
    //     password: values.password,
    //     email: values.emailId
    //   }
    // };
    // Login(loginData)
    //   .then((res: any) => {
    //     if (res.data) {
    //       const response: LoginApiResponse = res.data;
    //       const { token, refreshToken } = response?.data;
    //       dispatch(setToken({ token, refreshToken }));
    //       dispatch(setFirstLogin(true));
    //     } else {
    //       setShowAlert(true);
    //       setAlertData({
    //         type: 'error',
    //         heading: res?.error?.data?.message
    //       });
    //     }
    //   })
    //   .catch(error => {
    //     setShowAlert(true);
    //     setAlertData({
    //       type: 'error',
    //       heading: error?.data?.message
    //     });
    //     console.log('Error:', error);
    //   });
    const { token = '', refreshToken = '' } = {
      token: 'myToken',
      refreshToken: 'myRefreshToken'
    };
    dispatch(setToken({ token, refreshToken }));
    dispatch(setFirstLogin(true));
  };

  return (
    <>
      <main data-testid="sign-in-page">
        <div className="onboarding-screen-wrapper">
          <div className="inner-container">
            <div className="flex relative">
              <AuthenticationInfo />
              <div className="md:w-6/12 position-center">
                <div className="md:w-10/12 lg:w-8/12 w-11/12 mx-auto mobile-justify-center">
                  <p className="mt-5 text-center third-color font-semibold">
                    {t('Sign In')}
                  </p>
                  <div>
                    <Form
                      submitButtonText="Sign in"
                      handleSubmit={handleSubmit(handleSubmitForm)}
                      {...{ fields, register, errors }}>
                      {/* <div className="text-right mt-3">
                        <Button
                          btnStyle="link"
                          className="secondary-color"
                          >
                          {t('Forgot password')}?
                        </Button>
                      </div> */}
                    </Form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
