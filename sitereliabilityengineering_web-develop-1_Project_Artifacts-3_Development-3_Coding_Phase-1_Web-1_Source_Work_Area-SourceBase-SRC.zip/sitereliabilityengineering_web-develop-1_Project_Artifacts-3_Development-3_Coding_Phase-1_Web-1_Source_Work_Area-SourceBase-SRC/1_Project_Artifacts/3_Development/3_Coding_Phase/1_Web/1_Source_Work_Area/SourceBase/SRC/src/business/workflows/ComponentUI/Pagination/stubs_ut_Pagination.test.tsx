import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import Pagination from './Pagination';

describe('Pagination Component', () => {
  const onPageChange = jest.fn();

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should render the component with the correct number of pages', () => {
    const totalCount = 100;
    const pageSize = 10;
    const currentPage = 1;

    const { getByText } = render(
      <Pagination
        totalCount={totalCount}
        pageSize={pageSize}
        currentPage={currentPage}
        onPageChange={onPageChange}
      />
    );

    expect(getByText('1')).toBeInTheDocument();
    expect(getByText('10')).toBeInTheDocument();
  });

  it('should call the onPageChange function when a page button is clicked', () => {
    const totalCount = 100;
    const pageSize = 10;
    const currentPage = 1;

    const { getByText } = render(
      <Pagination
        totalCount={totalCount}
        pageSize={pageSize}
        currentPage={currentPage}
        onPageChange={onPageChange}
      />
    );

    fireEvent.click(getByText('2'));
    expect(onPageChange).toHaveBeenCalledTimes(1);
    expect(onPageChange).toHaveBeenCalledWith(2);
  });

  it('should render the correct number of sibling pages around the current page', () => {
    const totalCount = 100;
    const pageSize = 10;
    const currentPage = 5;

    const { getByText } = render(
      <Pagination
        totalCount={totalCount}
        pageSize={pageSize}
        currentPage={currentPage}
        onPageChange={onPageChange}
        siblingCount={2}
      />
    );

    expect(getByText('1')).toBeInTheDocument();
    expect(getByText('3')).toBeInTheDocument();
    expect(getByText('4')).toBeInTheDocument();
    expect(getByText('5')).toBeInTheDocument();
    expect(getByText('6')).toBeInTheDocument();
    expect(getByText('7')).toBeInTheDocument();
    expect(getByText('10')).toBeInTheDocument();
  });
});
