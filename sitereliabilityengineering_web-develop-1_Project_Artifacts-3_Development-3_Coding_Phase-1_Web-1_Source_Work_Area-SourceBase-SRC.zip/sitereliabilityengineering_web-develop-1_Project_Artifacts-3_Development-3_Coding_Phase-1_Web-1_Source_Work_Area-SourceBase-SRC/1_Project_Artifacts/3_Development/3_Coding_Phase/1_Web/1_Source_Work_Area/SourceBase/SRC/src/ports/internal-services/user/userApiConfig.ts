import type { ConfigFile } from '@rtk-query/codegen-openapi';
import { dotenv } from '../../../utils/constants/env';

const config: ConfigFile = {
  schemaFile: `${dotenv.API_BASE_URL}/swagger.json`,
  apiFile: './userApi.ts',
  apiImport: 'userApi',
  hooks: true,
  tag: true,
  outputFiles: {
    './userSlice.ts': {
      filterEndpoints: [
        'createUser',
        'login',
        'getCountries',
        'postForgotPassword'
      ]
    }
  }
};

export default config;
