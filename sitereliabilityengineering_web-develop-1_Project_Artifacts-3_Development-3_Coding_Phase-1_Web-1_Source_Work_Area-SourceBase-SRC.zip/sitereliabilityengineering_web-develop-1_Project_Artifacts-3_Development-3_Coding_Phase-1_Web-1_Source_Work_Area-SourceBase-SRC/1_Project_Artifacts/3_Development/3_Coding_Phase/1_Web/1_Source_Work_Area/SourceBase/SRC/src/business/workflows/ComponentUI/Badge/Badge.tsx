import { FC } from 'react';
import { BadgeProps } from '@business/interfaces/badge';

const getBadgeClassName = (btnStyle: string) => {
  switch (btnStyle) {
    case 'primary':
      return `button button-primary`;
    case 'secondary':
      return `button button-secondary`;
    case 'default-outline':
      return `button button-transparent`;
    default:
      return 'text-link';
  }
};

export const Badge: FC<BadgeProps> = ({
  btnStyle,
  className,
  onClick,
  size,
  fullWidth,
  label,
  children
}) => {
  const finalsClassName = `${getBadgeClassName(btnStyle)} ${className} ${
    fullWidth ? 'w-full' : ''
  } ${
    size === 'small' ? 'text-sm py-1' : size === 'large' ? 'text-lg py-3' : ''
  }`;
  return (
    <>
      <span
        data-testid="badge-tag"
        className={finalsClassName}
        onClick={onClick}>
        {label}
        {children}
      </span>
    </>
  );
};

Badge.defaultProps = {
  btnStyle: 'primary',
  className: ''
};
