import palette from './palette';
import shadows from './shadows';
import typography from './typography';
import spacing from './spacing';
const DefaultTheme = {
  colors: {}
};

const darkTheme = {
  ...DefaultTheme,
  roundness: 2,
  colors: {
    ...DefaultTheme.colors,
    ...palette.dark
  }
};

const lightTheme = {
  ...DefaultTheme,
  roundness: 2,
  colors: {
    ...DefaultTheme.colors,
    ...palette.light
  }
};

export { palette, shadows, typography, spacing, darkTheme, lightTheme };
