import { useTranslation } from 'next-i18next';
import { dotenv } from '@utils/constants/env';

export const Footer = () => {
  const { t } = useTranslation();
  return (
    <>
      {dotenv.IS_ADMIN === 'false' ? (
        <div
          className="w-full px-10 absolute bottom-4 left-0"
          data-testid="auth-footer">
          <p className="text-[#F2F2F2]">
            {t('Terms and Conditions')} &nbsp; | &nbsp; {t('Privacy Policy')}{' '}
            &nbsp; | &nbsp;
            {t('Copyright Site Reliability Engineering, 2023')}
          </p>
        </div>
      ) : (
        <div className="absolute bottom-28 pl-5 blue-500">
          {t('Terms and Conditions')} &nbsp; | &nbsp; {t('Privacy Policy')}{' '}
          &nbsp; | &nbsp;
          {t('Copyright Site Reliability Engineering, 2023')}
        </div>
      )}
    </>
  );
};
