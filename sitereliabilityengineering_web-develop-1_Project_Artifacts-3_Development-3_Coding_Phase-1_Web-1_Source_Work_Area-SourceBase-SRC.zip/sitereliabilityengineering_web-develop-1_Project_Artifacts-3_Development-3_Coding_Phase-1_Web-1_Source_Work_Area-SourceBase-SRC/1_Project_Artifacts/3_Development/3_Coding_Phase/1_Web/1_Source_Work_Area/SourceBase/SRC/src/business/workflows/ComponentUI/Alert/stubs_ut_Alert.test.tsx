import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { Alert } from './Alert';

describe('Alert component', () => {
  test('renders the heading and subheading', () => {
    const heading = 'Test Heading';
    const subHeading = 'Test Subheading';
    render(
      <Alert
        type="success"
        onClick={() => jest.fn()}
        heading={heading}
        subHeading={subHeading}
        isFocusable={false}
        autoHide={false}
      />
    );

    expect(screen.getByText(heading)).toBeInTheDocument();
    expect(screen.getByText(subHeading)).toBeInTheDocument();
  });

  test('renders the warning icon based on the type prop', () => {
    const type = 'warning';
    render(<Alert heading="Test Heading" type={type} />);

    expect(screen.getByTestId(type)).toBeInTheDocument();
  });

  test('renders the info icon based on the type prop', () => {
    const type = 'info';
    render(<Alert heading="Test Heading" type={type} />);

    expect(screen.getByTestId(type)).toBeInTheDocument();
  });

  test('renders the error icon based on the type prop', () => {
    const type = 'error';
    render(<Alert heading="Test Heading" type={type} />);
    expect(screen.getByTestId(type)).toBeInTheDocument();
  });

  test('renders the no icon based on the type prop', () => {
    const type = 'no-icon';
    render(<Alert heading="Test Heading" type={type} />);

    expect(screen.getByTestId(type)).toBeInTheDocument();
  });

  test('renders custom left and right icons', () => {
    const customLeftIcon = <div>Custom Left Icon</div>;
    const customRightIcon = <div>Custom Right Icon</div>;
    render(
      <Alert
        type="success"
        heading="Test Heading"
        customLeftIcon={customLeftIcon}
        customRightIcon={customRightIcon}
      />
    );

    expect(screen.getByText('Custom Left Icon')).toBeInTheDocument();
    expect(screen.getByText('Custom Right Icon')).toBeInTheDocument();
  });

  test('calls the onClose function when the close button is clicked', () => {
    const onClose = jest.fn();
    render(
      <Alert
        type="success"
        heading="Test Heading"
        isClosable={true}
        onClose={onClose}
      />
    );
    fireEvent.click(screen.getByTestId('close-icon'));
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  test('calls the onClick function when the alert box is clicked', () => {
    const onClick = jest.fn();
    render(<Alert type="success" heading="Test Heading" onClick={onClick} />);
    fireEvent.click(screen.getByText('Test Heading'));
    expect(onClick).toHaveBeenCalledTimes(1);
  });

  test('automatically hides after the specified duration', () => {
    jest.useFakeTimers();
    const onClose = jest.fn();
    const autoHideDuration = 1000;
    render(
      <Alert
        type="success"
        heading="Test Heading"
        onClose={onClose}
        autoHide
        autoHideDuration={autoHideDuration}
      />
    );

    jest.advanceTimersByTime(autoHideDuration);

    expect(onClose).toHaveBeenCalledTimes(1);
    jest.useRealTimers();
  });
});
