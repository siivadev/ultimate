import React from 'react';
import Image from 'next/image';
import { AvatarProps } from '@business/interfaces/avatar';

const Avatar: React.FC<AvatarProps> = ({
  src,
  alt,
  size = 'h-10 w-10',
  rounded = true,
  className = '',
  presence = false,
  placeholder = ''
}) => {
  const initials = alt
    ? alt
        .split(' ')
        .map(word => word[0])
        .join('')
    : '';

  const avatarClasses = `${size} ${
    rounded ? 'rounded-full' : 'rounded-none'
  } ${className}`;

  return (
    <div className={avatarClasses}>
      {src ? (
        <Image
          src={src}
          alt={alt}
          width={100}
          height={100}
          className="object-cover rounded-full"
        />
      ) : (
        <div className="w-full h-full rounded-full bg-gray-300 flex justify-center items-center text-gray-600 font-medium">
          {initials || placeholder}
        </div>
      )}
      {presence && (
        <div className="absolute bottom-0 right-0 w-3 h-3 border-2 border-white rounded-full bg-green-500"></div>
      )}
    </div>
  );
};

export default Avatar;
