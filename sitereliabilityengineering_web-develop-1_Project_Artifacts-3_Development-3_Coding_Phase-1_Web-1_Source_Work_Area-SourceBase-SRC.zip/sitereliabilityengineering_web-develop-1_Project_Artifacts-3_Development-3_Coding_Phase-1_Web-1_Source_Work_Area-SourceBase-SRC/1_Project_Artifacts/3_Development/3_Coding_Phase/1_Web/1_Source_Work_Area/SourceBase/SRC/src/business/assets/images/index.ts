/* eslint-disable global-require */

import BgImgSignin from './bg-img-signin.png';
import HamburgerIcon from './hamburger-icon.png';
import Man1 from './man-1.png';
import Man2 from './man-2.png';
import ProfileImage from './profile-image.png';
import SignInImage from './sign-in-image.png';
import AdminBg from './admin-bg.jpg';
import PreloginBanner from './prelogin-banner.jpg';

export const Images = {
  BgImgSignin,
  HamburgerIcon,
  Man1,
  Man2,
  ProfileImage,
  SignInImage,
  AdminBg,
  PreloginBanner
};
