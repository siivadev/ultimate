import { render, screen, fireEvent } from '@testing-library/react';
import { ComponentProvider } from '@business/workflows/ComponentHigherOrder';
import { SignIn } from './SignIn';

function SignInComponent() {
  return (
    <ComponentProvider>
      <SignIn />
    </ComponentProvider>
  );
}

describe('SignIn page', () => {
  beforeEach(() => {
    render(<SignInComponent />);
  });
  test('renders sign in page with email and password input fields', () => {
    const emailInput = screen.getByLabelText('Email');
    const passwordInput = screen.getByLabelText('Password');
    const signInButton = screen.getByRole('button', { name: 'Sign in' });
    const forgotPasswordLink = screen.getByRole('link', {
      name: 'Forgot password?'
    });

    expect(emailInput).toBeInTheDocument();
    expect(passwordInput).toBeInTheDocument();
    expect(signInButton).toBeInTheDocument();
    expect(forgotPasswordLink).toBeInTheDocument();
  });

  test('submits form with email and password values when sign in button is clicked', () => {
    const emailInput = screen.getByLabelText('Email');
    const passwordInput = screen.getByLabelText('Password');
    const signInButton = screen.getByRole('button', { name: 'Sign in' });

    const emailValue = 'test@test.com';
    const passwordValue = 'password123';

    fireEvent.change(emailInput, { target: { value: emailValue } });
    fireEvent.change(passwordInput, { target: { value: passwordValue } });
    fireEvent.click(signInButton);

    expect(emailInput).toHaveValue(emailValue);
    expect(passwordInput).toHaveValue(passwordValue);
  });
});
