import { userApi as api } from './userApi';
export const addTagTypes = ['Country', 'Users', 'Authentication'] as const;
const injectedRtkApi = api
  .enhanceEndpoints({
    addTagTypes
  })
  .injectEndpoints({
    endpoints: build => ({
      getCountries: build.query<GetCountriesApiResponse, GetCountriesApiArg>({
        query: () => ({ url: `/country` }),
        providesTags: ['Country']
      }),
      createUser: build.mutation<CreateUserApiResponse, CreateUserApiArg>({
        query: queryArg => ({
          url: `/user`,
          method: 'POST',
          body: queryArg.user
        }),
        invalidatesTags: ['Users']
      }),
      login: build.mutation<LoginApiResponse, LoginApiArg>({
        query: queryArg => ({
          url: `/login`,
          method: 'POST',
          body: queryArg.userLogin
        }),
        invalidatesTags: ['Authentication']
      }),
      postForgotPassword: build.mutation<
        PostForgotPasswordApiResponse,
        PostForgotPasswordApiArg
      >({
        query: queryArg => ({
          url: `/forgot-password`,
          method: 'POST',
          body: queryArg.email
        }),
        invalidatesTags: ['Authentication']
      })
    }),
    overrideExisting: false
  });
export { injectedRtkApi as enhancedApi };
export type GetCountriesApiResponse = /** status 200 Countries found. */ {
  ok?: boolean;
  data?: Country[];
  message?: string;
};
export type GetCountriesApiArg = void;
export type CreateUserApiResponse =
  /** status 201 User has been created successfully. */ {
    ok?: boolean;
    data?: User;
    message?: string;
  };
export type CreateUserApiArg = {
  /** User that needs to be added to the application */
  user: User;
};
export type LoginApiResponse = /** status 200 Success */ {
  ok?: boolean;
  data?: UserLoginResponse;
  message?: string;
};
export type LoginApiArg = {
  /** Request body containing user credentials */
  userLogin: UserLogin;
};
export type PostForgotPasswordApiResponse =
  /** status 200 Password reset will be sent in email */ Email;
export type PostForgotPasswordApiArg = {
  /** User information. */
  email: Email;
};
export type Country = {
  id: string;
  name: string;
  twoCharCountryCode: string;
  threeCharCountryCode: string;
  numericCode: string;
};
export type User = {
  organizationId: string;
  password: string;
  email: string;
  companySize: string;
  country: string;
};
export type UserLoginResponse = {
  token: string;
  refreshToken: string;
};
export type UserLogin = {
  password: string;
  email: string;
};
export type Email = {
  email: string;
};
export const {
  useGetCountriesQuery,
  useCreateUserMutation,
  useLoginMutation,
  usePostForgotPasswordMutation
} = injectedRtkApi;
