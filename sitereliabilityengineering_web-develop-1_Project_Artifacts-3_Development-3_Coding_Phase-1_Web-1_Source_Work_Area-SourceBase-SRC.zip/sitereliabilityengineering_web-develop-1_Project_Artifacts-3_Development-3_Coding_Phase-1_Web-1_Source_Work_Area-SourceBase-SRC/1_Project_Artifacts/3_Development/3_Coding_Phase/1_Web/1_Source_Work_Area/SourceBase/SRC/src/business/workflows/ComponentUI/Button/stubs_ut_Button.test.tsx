import { render, fireEvent } from '@testing-library/react';
import { Button } from './Button';

describe('Button', () => {
  it('renders a button with label', () => {
    const { getByText } = render(<Button label="Click me!" />);
    expect(getByText('Click me!')).toBeInTheDocument();
  });

  it('calls the onClick handler when clicked', () => {
    const handleClick = jest.fn();
    const { getByText } = render(
      <Button label="Click me!" onClick={handleClick} />
    );
    fireEvent.click(getByText('Click me!'));
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it('disables the button when isDisabled prop is true', () => {
    const { getByText } = render(
      <Button label="Click me!" isDisabled={true} />
    );
    expect(getByText('Click me!')).toBeDisabled();
  });

  it('renders start and end icons when provided', () => {
    const { getByTestId } = render(
      <Button
        label="Click me!"
        startIcon={<i data-testid="start-icon" />}
        endIcon={<i data-testid="end-icon" />}
        loading={false}
      />
    );
    expect(getByTestId('start-icon')).toBeInTheDocument();
    expect(getByTestId('end-icon')).toBeInTheDocument();
  });

  it('renders a secondary button', () => {
    const { getByText } = render(
      <Button label="Click me!" btnStyle="secondary" />
    );
    expect(getByText('Click me!').className).toContain('button-secondary');
  });

  it('renders a default-outline button', () => {
    const { getByText } = render(
      <Button label="Click me!" btnStyle="default-outline" />
    );
    expect(getByText('Click me!').className).toContain('button-transparent');
  });

  it('renders a link button', () => {
    const { getByText } = render(<Button label="Click me!" btnStyle="link" />);
    expect(getByText('Click me!').className).toContain('link');
  });

  it('renders a full width button', () => {
    const { getByText } = render(<Button label="Click me!" fullWidth={true} />);
    expect(getByText('Click me!').className).toContain('w-full');
  });
  it('renders a small button', () => {
    const { getByText } = render(<Button label="Click me!" size="small" />);
    expect(getByText('Click me!').className).toContain('text-sm');
  });
  it('renders a large button', () => {
    const { getByText } = render(<Button label="Click me!" size="large" />);
    expect(getByText('Click me!').className).toContain('text-lg');
  });
  it('renders a loader button', () => {
    const { getByTestId } = render(<Button label="Click me!" loading={true} />);
    expect(getByTestId('button-loader')).toBeInTheDocument();
  });

  it('renders a link when href prop is provided', () => {
    const { getByText } = render(
      <Button label="Click me!" href="https://example.com" />
    );
    expect(getByText('Click me!').tagName).toBe('A');
  });

  it('renders a link with start and end icons', () => {
    const { getByText, getByTestId } = render(
      <Button
        label="Click me!"
        href="https://example.com"
        startIcon={<i data-testid="start-icon" />}
        endIcon={<i data-testid="end-icon" />}
      />
    );
    expect(getByText('Click me!').tagName).toBe('A');
    expect(getByTestId('start-icon')).toBeInTheDocument();
    expect(getByTestId('end-icon')).toBeInTheDocument();
  });

  it('renders a link with loader', () => {
    const { getByText, getByTestId } = render(
      <Button label="Click me!" href="https://example.com" loading={true} />
    );
    expect(getByText('Click me!').tagName).toBe('A');
    expect(getByTestId('button-loader')).toBeInTheDocument();
  });
});
