export function addAlpha(color: string, opacity: number) {
  const _opacity = Math.round(Math.min(Math.max(opacity || 1, 0), 1) * 255);
  return color + _opacity.toString(16).toUpperCase();
}

export function makeLightenColorFromHex(color: string, opacity: number) {
  const num = parseInt(color.replace('#', ''), 16);
  const r = (num >> 16) + opacity;
  const b = ((num >> 8) & 0x00ff) + opacity;
  const g = (num & 0x0000ff) + opacity;
  const newColor = g | (b << 8) | (r << 16);
  return '#' + newColor.toString(16);
}
