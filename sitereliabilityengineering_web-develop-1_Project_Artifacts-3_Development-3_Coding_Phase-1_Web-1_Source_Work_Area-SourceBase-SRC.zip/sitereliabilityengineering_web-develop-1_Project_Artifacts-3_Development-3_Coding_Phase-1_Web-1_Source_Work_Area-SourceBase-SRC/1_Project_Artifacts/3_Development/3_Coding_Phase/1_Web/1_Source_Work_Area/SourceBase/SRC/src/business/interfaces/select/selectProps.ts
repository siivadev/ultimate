type option = {
  value: string;
  label: string;
};
export interface SelectProps
  extends React.SelectHTMLAttributes<HTMLSelectElement> {
  inputWrapperClassName?: string;
  label?: string;
  labelClassName?: string;
  fieldSize?: 'small' | 'medium' | 'large';
  color?:
    | 'primary'
    | 'secondary'
    | 'error'
    | 'info'
    | 'success'
    | 'warning'
    | string;
  error?: string;
  options?: option[];
  startDecorator?: React.ReactNode;
  endDecorator?: React.ReactNode;
}
