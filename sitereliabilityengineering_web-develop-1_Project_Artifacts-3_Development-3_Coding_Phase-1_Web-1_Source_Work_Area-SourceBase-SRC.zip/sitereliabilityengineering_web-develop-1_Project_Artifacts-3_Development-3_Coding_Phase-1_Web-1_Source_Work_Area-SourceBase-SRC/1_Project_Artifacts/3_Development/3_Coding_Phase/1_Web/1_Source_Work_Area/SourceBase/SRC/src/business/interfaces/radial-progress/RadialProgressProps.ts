export interface RadialProgressProps {
  color?: 'primary' | 'secondary';
  size?: 'small' | 'medium' | 'large';
  label?: string;
  progress?: number;
  height?: number;
  wrapperClass?: string;
  className?: string;
  shape?: 'circle' | 'ellipse';
}
