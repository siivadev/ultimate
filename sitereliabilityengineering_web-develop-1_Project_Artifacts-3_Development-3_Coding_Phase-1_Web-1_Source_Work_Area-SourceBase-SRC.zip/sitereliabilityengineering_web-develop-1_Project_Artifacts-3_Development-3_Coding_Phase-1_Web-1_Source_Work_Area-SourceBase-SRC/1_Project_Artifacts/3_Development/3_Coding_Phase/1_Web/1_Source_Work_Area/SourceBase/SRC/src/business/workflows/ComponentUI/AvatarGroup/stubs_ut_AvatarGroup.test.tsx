import React from 'react';
import { render, screen } from '@testing-library/react';
import AvatarGroup from './AvatarGroup';

describe('AvatarGroup', () => {
  const avatars = [
    { src: 'https://example.com/image1.png', alt: 'Avatar 1' },
    { src: 'https://example.com/image2.png', alt: 'Avatar 2' },
    { src: 'https://example.com/image3.png', alt: 'Avatar 3' },
    { src: 'https://example.com/image4.png', alt: 'Avatar 4' },
    { src: 'https://example.com/image5.png', alt: 'Avatar 5' }
  ];

  it('renders the avatars', () => {
    render(<AvatarGroup avatars={avatars} maxToShow={5} />);
    const avatarElements = screen.getAllByRole('img');
    expect(avatarElements.length).toBe(5);
  });

  it('displays the remaining count', () => {
    render(<AvatarGroup avatars={avatars} maxToShow={3} />);
    const remainingCountElement = screen.getByText('+2');
    expect(remainingCountElement).toBeInTheDocument();
  });

  it('displays the length of the avatars array', () => {
    render(<AvatarGroup avatars={avatars} maxToShow={10} />);
    const lengthElement = screen.getByText('5');
    expect(lengthElement).toBeInTheDocument();
  });
});
