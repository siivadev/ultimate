import React, { FC, useState } from 'react';
import { RadioGroupProps } from '@business/interfaces/radio-group';

const RadioGroup: FC<RadioGroupProps> = ({
  size,
  color,
  options,
  onChange
}) => {
  const [selectedValue, setSelectedValue] = useState<string>('');

  const handleRadioChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedValue(event.target.value);
    if (onChange) {
      onChange(event.target.value);
    }
  };

  return (
    <div>
      {options.map(option => (
        <label key={option.value}>
          <input
            type="radio"
            name="radio-group"
            value={option.value}
            checked={selectedValue === option.value}
            onChange={handleRadioChange}
            disabled={option.disabled ?? false}
            style={{
              fontSize:
                size === 'small' ? '12px' : size === 'medium' ? '16px' : '20px',
              color: option.disabled ? 'gray' : color
            }}
          />
          {option.label}
        </label>
      ))}
    </div>
  );
};

export default RadioGroup;
