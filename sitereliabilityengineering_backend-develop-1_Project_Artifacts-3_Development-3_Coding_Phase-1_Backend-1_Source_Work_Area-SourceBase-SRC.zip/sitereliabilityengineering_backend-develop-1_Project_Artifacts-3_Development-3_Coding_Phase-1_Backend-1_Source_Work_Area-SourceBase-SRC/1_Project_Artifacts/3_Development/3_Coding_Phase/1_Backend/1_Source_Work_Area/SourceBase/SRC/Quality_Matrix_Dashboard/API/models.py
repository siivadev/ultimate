from django.db import models


class Commit(models.Model):
    commit_id = models.CharField(max_length=50,unique=True)
    author = models.CharField(max_length=100)
    date = models.DateField()
    time = models.TimeField()
    additions = models.IntegerField()
    deletions = models.IntegerField()
    build_unique_refer_id = models.CharField(max_length=100, default=False)
    project_name=models.CharField(max_length=50, default=False)

class BuildMasterTable(models.Model):
    uniquereferid = models.IntegerField()
    Buildno = models.IntegerField(primary_key=True)
    Datetime = models.DateTimeField()
    status = models.BooleanField(default=False)
    projectreference = models.CharField(max_length=50)

class ClientTable(models.Model):
    clientid = models.IntegerField(primary_key=True)
    clientname = models.CharField(max_length=50)
    Dateadded = models.DateTimeField()
    IsActive= models.BooleanField(default=False)
    uniquereferid = models.ForeignKey(BuildMasterTable, on_delete=models.CASCADE)

class ProjectTable(models.Model):
    clientid = models.ForeignKey(ClientTable, on_delete=models.CASCADE)
    Projectid = models.IntegerField(primary_key=True)
    projectname=models.CharField(max_length=50)
    Dateadded = models.DateTimeField()
    IsActive= models.BooleanField(default=False)

class ClocTable(models.Model):
    language = models.CharField(max_length=50)
    files = models.IntegerField()
    blank=models.IntegerField()
    comment = models.IntegerField()
    code= models.IntegerField()
    
    