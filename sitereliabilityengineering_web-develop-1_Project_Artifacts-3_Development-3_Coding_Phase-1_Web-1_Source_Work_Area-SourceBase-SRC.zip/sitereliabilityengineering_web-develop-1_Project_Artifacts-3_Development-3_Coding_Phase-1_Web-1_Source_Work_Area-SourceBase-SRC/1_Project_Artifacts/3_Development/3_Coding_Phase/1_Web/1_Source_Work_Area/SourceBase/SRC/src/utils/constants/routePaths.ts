export const routePaths = {
  Dashboard: '/dashboard',
  Home: '/home',
  SignIn: '/sign-in'
};
