import type { ReactNode } from 'react';

export interface BadgeProps {
  btnStyle?: 'primary' | 'secondary' | 'default-outline' | 'link';
  className?: string;
  onClick?: () => void;
  size?: 'small' | 'medium' | 'large';
  fullWidth?: boolean;
  label?: string;
  children?: ReactNode;
}
