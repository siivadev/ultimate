import { render } from '@testing-library/react';
import Card from './Card';

describe('Card', () => {
  it('renders children', () => {
    const { getByText } = render(
      <Card>
        <p>Test content</p>
      </Card>
    );
    expect(getByText('Test content')).toBeInTheDocument();
  });

  it('adds the wrapper class to the outer div', () => {
    const { container } = render(
      <Card wrapperClass="test-class">
        <p>Test content</p>
      </Card>
    );
    expect(container.firstChild).toHaveClass('test-class');
  });
});
