import { render, screen, fireEvent } from '@testing-library/react';
import { InputField } from './InputField';

describe('InputField', () => {
  it('renders component', () => {
    const name = 'text';
    render(<InputField name={name} />);
    expect(screen.getByTestId(`input-field-${name}`)).toBeInTheDocument();
  });

  it('renders a label element when the label prop is passed', () => {
    const { getByTestId } = render(<InputField label="Username" />);
    expect(getByTestId('input-label')).toBeInTheDocument();
    expect(getByTestId('input-label')).toHaveTextContent('Username');
  });

  it('disables the input field when the disabled prop is true', () => {
    const name = 'text';
    const { getByTestId } = render(
      <InputField disabled={true} label="Username" name={name} />
    );
    const inputElement = getByTestId(`input-field-${name}`);
    expect(inputElement).toBeDisabled();
  });
  it('calls the onChange function when the input value changes', () => {
    const name = 'text';
    const onChange = jest.fn();
    const { getByTestId } = render(
      <InputField onChange={onChange} name={name} />
    );
    const inputElement = getByTestId(`input-field-${name}`);
    fireEvent.change(inputElement, { target: { value: 'hello' } });
    expect(onChange).toHaveBeenCalledTimes(1);
  });
  it('renders an error message when the error prop is passed', () => {
    const { getByText } = render(<InputField error="Invalid input" />);
    const errorElement = getByText('Invalid input');
    expect(errorElement).toBeInTheDocument();
  });
  it('renders start and end icons when provided', () => {
    const { getByTestId } = render(
      <InputField
        startDecorator={<i data-testid="start-icon" />}
        endDecorator={<i data-testid="end-icon" />}
      />
    );
    expect(getByTestId('start-icon')).toBeInTheDocument();
    expect(getByTestId('end-icon')).toBeInTheDocument();
  });
});
