export interface SwitchProps {
  color?: 'primary' | 'secondary ';
  size?: 'small' | 'medium' | 'large';
  label?: string;
  controlled?: boolean;
  checked?: boolean;
  onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
}
