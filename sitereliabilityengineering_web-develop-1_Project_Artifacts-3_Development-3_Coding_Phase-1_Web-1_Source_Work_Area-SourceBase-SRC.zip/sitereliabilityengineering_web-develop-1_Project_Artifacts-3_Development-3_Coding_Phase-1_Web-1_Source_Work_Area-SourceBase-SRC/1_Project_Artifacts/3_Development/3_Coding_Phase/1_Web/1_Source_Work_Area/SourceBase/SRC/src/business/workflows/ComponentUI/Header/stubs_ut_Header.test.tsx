import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import { ComponentProvider } from '@business/workflows/ComponentHigherOrder';
import { Header } from './Header';

function HeaderElement() {
  const mockProps = {
    topNavigation: true
  };
  return (
    <ComponentProvider>
      <Header {...mockProps} />
    </ComponentProvider>
  );
}
describe('Header', () => {
  beforeEach(() => {
    render(<HeaderElement />);
  });

  it('should render the component with the correct links', () => {
    expect(screen.getByText('For me')).toBeInTheDocument();
    expect(screen.getByText('For My Team')).toBeInTheDocument();
  });

  it('displays the logo', () => {
    expect(screen.getByAltText('logo')).toBeInTheDocument();
  });

  it('displays the search box with icon', () => {
    expect(screen.getByTestId('input-field-search')).toBeInTheDocument();
    expect(screen.getByAltText('search-icon')).toBeInTheDocument();
  });

  it('displays the "Become a Leader" button', () => {
    expect(screen.getByText('Become a Leader')).toBeInTheDocument();
  });

  it('displays the "Sign In" button', () => {
    expect(screen.getAllByText('Sign In')).toHaveLength(2);
  });

  it('should update the active link when a link is clicked', () => {
    const forMeLink = screen.getByText('For me');
    const forMyTeamLink = screen.getByText('For My Team');
    fireEvent.click(forMeLink);
    expect(forMeLink).toHaveClass('primary-bottom-border');
    expect(forMyTeamLink).not.toHaveClass('primary-bottom-border');
    fireEvent.click(forMyTeamLink);
    expect(forMeLink).not.toHaveClass('primary-bottom-border');
    expect(forMyTeamLink).toHaveClass('primary-bottom-border');
  });
});
