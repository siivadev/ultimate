/* eslint no-use-before-define: 0 */
const fs = require('fs');
const glob = require('glob');
const pagesDir = 'src/pages';
const basePath = 'src/utils/constants';
if (!fs.existsSync(basePath)) {
  fs.mkdirSync(basePath);
}
const jsUcWord = name =>
  name
    .trim()
    .replace(/\s\s+/g, ' ')
    .replace('/', '-')
    .split('-')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join('');

const folderNames = () => {
  const pageFilePaths = glob.sync(`${pagesDir}/**/*.tsx`);
  const pagePaths = pageFilePaths.map(filePath =>
    filePath.replace(`${pagesDir}/`, '').replace('/index.tsx', '').replace('.tsx', '')
  ).filter(filePath => filePath!=='index' && filePath!=='_app');

  return Array.from(new Set(pagePaths));
};

const generate = () => {
  const components = folderNames()
    .map(name => {
      return `${jsUcWord(name)}: '/${name}'`;
    })
    .join(',\n  ');

  const fileContentString = `export const routePaths={
  ${components.length !== 0 && components}
};
`;

  fs.writeFileSync(basePath + '/routePaths.ts', fileContentString, 'utf8');
};
generate();
