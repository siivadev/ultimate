import { fetchBaseQuery } from '@reduxjs/toolkit/query';

import type {
  BaseQueryFn,
  FetchArgs,
  FetchBaseQueryError
} from '@reduxjs/toolkit/query';
import { dotenv } from '@utils/constants/env';
import { store } from './store';

const baseQuery = fetchBaseQuery({
  baseUrl: dotenv.API_BASE_URL,
  prepareHeaders: headers => {
    const token: string = store.getState().sessionStateSlice.token;
    if (token) {
      headers.set('authorization', `Bearer ${token}`);
    }
    return headers;
  }
});

export const baseQueryWithAuth: BaseQueryFn<
  string | FetchArgs,
  unknown,
  FetchBaseQueryError
> = async (args, api, extraOptions) => {
  let result = await baseQuery(args, api, extraOptions);
  if (typeof result.error != 'undefined') {
    //console.log(result.error, result.error.status);
    if (result.error && result.error.status === 400) {
      // api.dispatch({type: 'INCREMENT'});
    } else if (
      result.error &&
      result.error.status === 500 &&
      (result.error?.data as Error).message === 'jwt expired'
    ) {
      // api.dispatch(loggedOut());
    }
  }
  return result;
};
