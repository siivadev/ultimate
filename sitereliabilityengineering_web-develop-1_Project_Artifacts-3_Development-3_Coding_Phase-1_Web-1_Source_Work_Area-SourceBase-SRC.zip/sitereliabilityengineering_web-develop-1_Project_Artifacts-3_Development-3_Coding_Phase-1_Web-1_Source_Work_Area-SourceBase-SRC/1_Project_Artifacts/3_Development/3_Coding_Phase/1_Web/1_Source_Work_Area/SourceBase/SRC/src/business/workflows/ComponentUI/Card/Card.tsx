import React from 'react';
import { CardProps } from '@business/interfaces/card';

const Card = ({ children, wrapperClass }: CardProps) => {
  return <div className={`card ${wrapperClass}`}>{children}</div>;
};

export default Card;
