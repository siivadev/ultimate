import React from 'react';
import { AvatarGroupProps } from '@business/interfaces/avatar-group';
import Avatar from '../Avatar/Avatar';

const AvatarGroup: React.FC<AvatarGroupProps> = ({ avatars, maxToShow }) => {
  const remainingCount = avatars.length - maxToShow;
  const avatarsToShow = avatars.slice(0, maxToShow);

  return (
    <div className="avatar-group -space-x-6">
      {avatarsToShow.map(avatar => (
        <div className="avatar" key={avatar.src}>
          <div className="w-12">
            <Avatar {...avatar} />
          </div>
        </div>
      ))}

      {remainingCount > 0 && (
        <div className="avatar placeholder">
          <div className="w-12 bg-neutral-focus text-neutral-content">
            <span>+{remainingCount}</span>
          </div>
        </div>
      )}

      {maxToShow > avatars.length && (
        <div className="avatar placeholder">
          <div className="w-12 bg-neutral-focus text-neutral-content">
            <span>{avatars.length}</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default AvatarGroup;
