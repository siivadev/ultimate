import { AnyAction, ThunkMiddleware, configureStore } from '@reduxjs/toolkit';
import { ToolkitStore } from '@reduxjs/toolkit/dist/configureStore';
import { SessionSignUpType } from '@business/entities/session';
import {
  sessionSignUpSlice,
  resetSessionSignUpState
} from './signUpStateSlice';

describe('SignUpStateSlice', () => {
  let store: ToolkitStore<
    { signUpState: SessionSignUpType },
    AnyAction,
    [ThunkMiddleware<{ signUpState: SessionSignUpType }, AnyAction>]
  >;

  beforeEach(() => {
    store = configureStore({
      reducer: {
        signUpState: sessionSignUpSlice.reducer
      }
    });
  });

  afterEach(() => {
    store.dispatch(resetSessionSignUpState());
  });

  it('should set sign up details', () => {
    const name = 'John';
    const mobileNumber = '1234567890';
    const emailId = 'john@test.com';
    const password = 'Password@123';

    store.dispatch(
      sessionSignUpSlice.actions.setSignUpDetails({
        name,
        mobileNumber,
        emailId,
        password
      })
    );

    const signUpState = store.getState().signUpState;

    expect(signUpState.name).toEqual(name);
    expect(signUpState.mobileNumber).toEqual(mobileNumber);
    expect(signUpState.emailId).toEqual(emailId);
    expect(signUpState.password).toEqual(password);
  });

  it('should reset sign up state', () => {
    store.dispatch(
      sessionSignUpSlice.actions.setSignUpDetails({
        name: 'John',
        mobileNumber: '1234567890',
        emailId: 'john@test.com',
        password: 'Password@123'
      })
    );

    store.dispatch(resetSessionSignUpState());

    const signUpState = store.getState().signUpState;

    expect(signUpState.name).toEqual('');
    expect(signUpState.mobileNumber).toEqual('');
    expect(signUpState.emailId).toEqual('');
    expect(signUpState.password).toEqual('');
  });
});
