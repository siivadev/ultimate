export interface HeaderProps {
  topNavigation?: boolean;
}
