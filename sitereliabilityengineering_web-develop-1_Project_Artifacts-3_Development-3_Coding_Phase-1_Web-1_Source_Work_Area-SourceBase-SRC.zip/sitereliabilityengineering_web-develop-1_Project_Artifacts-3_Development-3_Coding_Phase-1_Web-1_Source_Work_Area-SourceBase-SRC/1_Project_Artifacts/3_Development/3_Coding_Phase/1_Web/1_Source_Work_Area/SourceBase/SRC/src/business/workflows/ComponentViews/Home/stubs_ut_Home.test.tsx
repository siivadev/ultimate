import { render, screen } from '@testing-library/react';
import { ComponentProvider } from '@business/workflows/ComponentHigherOrder';
import { Home } from './Home';

function HomeComponent() {
  return (
    <ComponentProvider>
      <Home />
    </ComponentProvider>
  );
}

describe('HOME SCREEN', () => {
  test('is rendered', async () => {
    render(<HomeComponent />);
    expect(screen.getByTestId('home-page')).toBeInTheDocument();
  });
});
