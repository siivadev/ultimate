import '@testing-library/jest-dom';
window.HTMLElement.prototype.scrollIntoView = jest.fn
jest.mock('next/router', () => require('next-router-mock'));