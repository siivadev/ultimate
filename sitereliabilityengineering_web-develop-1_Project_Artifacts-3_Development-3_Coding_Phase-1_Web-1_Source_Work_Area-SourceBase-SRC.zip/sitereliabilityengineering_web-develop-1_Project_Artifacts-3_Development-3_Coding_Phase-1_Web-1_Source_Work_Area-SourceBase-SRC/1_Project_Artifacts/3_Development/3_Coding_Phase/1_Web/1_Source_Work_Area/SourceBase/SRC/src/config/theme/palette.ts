import { addAlpha } from '@utils/helpers';

// SETUP COLORS
const GREY = {
  0: '#FFFFFF',
  100: '#F9FAFB',
  200: '#F4F6F8',
  300: '#DFE3E8',
  400: '#C4CDD5',
  500: '#aeaeae',
  600: '#637381',
  700: '#454F5B',
  800: '#212B36',
  900: '#161C24',
  500_8: addAlpha('#919EAB', 0.08),
  500_12: addAlpha('#919EAB', 0.12),
  500_16: addAlpha('#919EAB', 0.16),
  500_24: addAlpha('#919EAB', 0.24),
  500_32: addAlpha('#919EAB', 0.32),
  500_48: addAlpha('#919EAB', 0.48),
  500_56: addAlpha('#919EAB', 0.56),
  500_80: addAlpha('#919EAB', 0.8)
};

const COMMON = {
  primary: '#178c03',
  secondary: '#3366FF',
  info: '#1890FF',
  success: '#54D62C',
  warning: '#FFC107',
  error: '#EB6B63'
};

const palette = {
  light: {
    ...COMMON,
    text: GREY[800],
    surface: '#fff',
    background: '#fff'
  },
  dark: {
    ...COMMON,
    text: '#fff',
    surface: GREY[900],
    background: GREY[900]
  },
  grey: GREY
};

export default palette;
