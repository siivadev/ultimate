import { AvatarProps } from '../avatar/AvatarProps';

export interface AvatarGroupProps {
  avatars: AvatarProps[];
  maxToShow: number;
}
