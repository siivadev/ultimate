export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  inputWrapperClassName?: string;
  label?: string;
  labelClassName?: string;
  fieldSize?: 'small' | 'medium' | 'large';
  color?:
    | 'primary'
    | 'secondary'
    | 'error'
    | 'info'
    | 'success'
    | 'warning'
    | string;
  error?: string;
  startDecorator?: React.ReactNode;
  endDecorator?: React.ReactNode;
}
