import React from 'react';
import { ListItemsProps } from '@business/interfaces/list-items';

const ListItems = ({
  wrapperClass = '',
  listItemClass = '',
  items
}: ListItemsProps) => {
  return (
    <ul className={wrapperClass}>
      {items.map(({ key, item }) => (
        <li key={key} className={listItemClass}>
          {item}
        </li>
      ))}
    </ul>
  );
};

export default ListItems;
