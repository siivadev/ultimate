module.exports = {
  presets: ['next/babel'],
  plugins: [
    [
      'module-resolver',
      {
        alias: {
          '@adapters': './src/adapters',
          '@business': './src/business',
          '@config': './src/config',
          '@utils': './src/utils',
          '@ports': './src/ports',
        },
      },
    ],
  ],
};
