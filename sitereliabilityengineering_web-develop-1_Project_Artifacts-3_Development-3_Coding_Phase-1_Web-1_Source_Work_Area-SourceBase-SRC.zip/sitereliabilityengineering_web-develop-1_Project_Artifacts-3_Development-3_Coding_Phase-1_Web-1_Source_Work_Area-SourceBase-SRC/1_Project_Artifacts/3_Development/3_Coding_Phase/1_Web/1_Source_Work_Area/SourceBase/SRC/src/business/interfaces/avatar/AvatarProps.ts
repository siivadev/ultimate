export type AvatarProps = {
  src?: string;
  alt?: string;
  size?: string;
  rounded?: boolean;
  className?: string;
  presence?: boolean;
  placeholder?: string;
};
