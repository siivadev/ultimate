import { InputField, Select } from '@business/workflows/ComponentUI';
import { Checkbox } from '@business/workflows/ComponentUI/Checkbox';

export function generateField(props: any) {
  switch (props.type) {
    case 'select':
      return <Select {...props} />;
    case 'checkbox':
      return <Checkbox {...props} />;
    case 'radio':
      return <Select {...props} />;
    default:
      return <InputField {...props} />;
  }
}
