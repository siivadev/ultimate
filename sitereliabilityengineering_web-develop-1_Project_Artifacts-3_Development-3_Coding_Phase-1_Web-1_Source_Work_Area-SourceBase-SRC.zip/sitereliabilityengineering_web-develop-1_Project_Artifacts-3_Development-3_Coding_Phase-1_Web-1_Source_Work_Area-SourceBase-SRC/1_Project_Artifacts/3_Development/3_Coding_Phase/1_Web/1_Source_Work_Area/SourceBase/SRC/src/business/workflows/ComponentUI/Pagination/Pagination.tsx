import React, { FC } from 'react';
import { PaginationProps } from '@business/interfaces/pagination';

const Pagination: FC<PaginationProps> = ({
  totalCount,
  currentPage,
  pageSize,
  onPageChange,
  siblingCount = 1,
  dots = '...'
}) => {
  const totalPages = Math.ceil(totalCount / pageSize);

  const getPageNumbers = () => {
    const pages = [];

    // Add first page
    pages.push(1);

    // Add pages around current page
    for (
      let i = currentPage - siblingCount;
      i <= currentPage + siblingCount;
      i++
    ) {
      if (i > 1 && i < totalPages) {
        pages.push(i);
      }
    }

    // Add last page
    pages.push(totalPages);

    // Add dots
    const pageNumbers = [];
    let prevPage = 0;
    for (let i = 0; i < pages.length; i++) {
      const page = pages[i];
      if (page - prevPage === 2) {
        pageNumbers.push(prevPage + 1);
      } else if (page - prevPage > 2) {
        pageNumbers.push(dots);
      }
      pageNumbers.push(page);
      prevPage = page;
    }

    return pageNumbers;
  };

  const handleClick = (page: any) => {
    if (onPageChange) {
      onPageChange(page);
    }
  };

  const pageNumbers = getPageNumbers();

  return (
    <div className="pagination">
      {pageNumbers.map((page, index) => {
        if (page === dots) {
          return <span key={index}>{dots}</span>;
        }
        return (
          <button
            key={index}
            onClick={() => handleClick(page)}
            className={currentPage === page ? 'active' : ''}>
            {page}
          </button>
        );
      })}
    </div>
  );
};

export default Pagination;
