import { render } from '@testing-library/react';
import { Table } from './Table';

describe('Table', () => {
  const tableData = [
    { name: 'Alice', age: 25 },
    { name: 'Bob', age: 30 },
    { name: 'Charlie', age: 35 }
  ];
  const tableColumns = [
    { Header: 'Name', accessor: 'name' },
    { Header: 'Age', accessor: 'age' }
  ];

  it('renders the table headers and rows', () => {
    const { getByText } = render(
      <Table tableData={tableData} tableColumns={tableColumns} />
    );

    const nameHeader = getByText('Name');
    const ageHeader = getByText('Age');

    expect(nameHeader).toBeInTheDocument();
    expect(ageHeader).toBeInTheDocument();

    const aliceRow = getByText('Alice');
    const bobRow = getByText('Bob');
    const charlieRow = getByText('Charlie');

    expect(aliceRow).toBeInTheDocument();
    expect(bobRow).toBeInTheDocument();
    expect(charlieRow).toBeInTheDocument();
  });

  it('updates the table when props change', () => {
    const { rerender, getByText } = render(
      <Table tableData={tableData} tableColumns={tableColumns} />
    );
    const initialAliceRow = getByText('Alice');
    const newTableData = [
      { name: 'Dave', age: 40 },
      { name: 'Eve', age: 45 }
    ];
    const newTableColumns = [
      { Header: 'Name', accessor: 'name' },
      { Header: 'Age', accessor: 'age' },
      { Header: 'Gender', accessor: 'gender' }
    ];
    rerender(<Table tableData={newTableData} tableColumns={newTableColumns} />);
    expect(initialAliceRow).toBeInTheDocument(); //    expect(initialAliceRow).not.toBeInTheDocument();
    const daveRow = getByText('Dave');
    const eveRow = getByText('Eve');
    expect(daveRow).toBeInTheDocument();
    expect(eveRow).toBeInTheDocument();
  });
});
