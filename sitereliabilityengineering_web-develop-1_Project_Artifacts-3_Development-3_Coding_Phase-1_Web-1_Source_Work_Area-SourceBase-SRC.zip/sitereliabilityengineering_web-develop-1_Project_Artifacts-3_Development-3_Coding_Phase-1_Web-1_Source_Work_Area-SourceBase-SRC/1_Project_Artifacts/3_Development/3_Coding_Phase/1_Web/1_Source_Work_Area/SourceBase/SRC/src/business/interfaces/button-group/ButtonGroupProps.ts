import { Button, ButtonProps } from '../button';

export interface ButtonGroupProps extends ButtonProps {
  buttons: Button[];
}
