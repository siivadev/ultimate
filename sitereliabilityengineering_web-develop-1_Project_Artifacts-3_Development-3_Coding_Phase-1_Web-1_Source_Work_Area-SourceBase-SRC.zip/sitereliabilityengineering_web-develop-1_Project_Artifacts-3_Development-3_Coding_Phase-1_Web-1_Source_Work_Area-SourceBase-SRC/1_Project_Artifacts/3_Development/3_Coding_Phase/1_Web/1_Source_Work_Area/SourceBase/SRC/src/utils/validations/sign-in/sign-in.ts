import * as yup from 'yup';
import { regexExp } from '@business/rules/regex';

export const signInSchema = yup.object().shape({
  emailId: yup
    .string()
    .email('Email Id is not valid')
    .matches(regexExp.emailRegex, 'Email Id is not valid')
    .required('Email Id is required'),
  password: yup
    .string()
    .test(
      'empty',
      'Password is required',
      value => value !== undefined && value !== null && value !== ''
    )
    .matches(
      regexExp.passwordRegex,
      'Password must contain at least one letter, one digit, one special character and is at least 8 characters long'
    )
    .test('password-requirements', 'Password meets the requirements', value => {
      if (value !== undefined && value !== null && value !== '') {
        return regexExp.passwordRegex.test(value);
      }
      return true;
    })
    .required('Password is required')
});
