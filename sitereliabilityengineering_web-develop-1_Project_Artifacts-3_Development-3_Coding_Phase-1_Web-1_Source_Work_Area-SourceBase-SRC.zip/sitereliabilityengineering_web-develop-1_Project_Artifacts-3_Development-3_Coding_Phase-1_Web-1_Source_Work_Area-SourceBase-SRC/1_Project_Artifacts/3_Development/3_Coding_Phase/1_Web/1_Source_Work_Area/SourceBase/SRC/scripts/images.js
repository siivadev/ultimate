/* eslint no-use-before-define: 0 */
const fs = require('fs');
const basePath = 'src/business/assets';
const jsUcWord = (name) =>
  name
    .trim()
    .replace(/\s\s+/g, ' ')
    .split('-')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join('')
    .split('_')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join('');

const imageFileNamesPng = () => {
  let array = fs
    .readdirSync(basePath+'/images')
    .filter(file => {
      return file.endsWith('.png');
    })
    .map(file => {
      return file
        .replace('@1x.png', '')
        .replace('@2x.png', '')
        .replace('@3x.png', '')
        .replace('.png', '');
    });

  array = array.filter(file => {
    if (array.includes(`${file}-rtl`)) {
      return false;
    }
    return true;
  });

  return Array.from(new Set(array));
};

const imageFileNamesJpg = () => {
  const array = fs
    .readdirSync(basePath+'/images')
    .filter(file => {
      return file.endsWith('.jpg');
    })
    .map(file => {
      return file.replace('.jpg', '');
    });

  return Array.from(new Set(array));
};

const imageFileNamesSvg = () => {
  const array = fs
    .readdirSync(basePath+'/vectors')
    .filter(file => {
      return file.endsWith('.svg');
    })
    .map(file => {
      return file.replace('.svg', '');
    });

  return Array.from(new Set(array));
};

const generate = () => {
  const excludedList = [];
  const propertiesPng = imageFileNamesPng()
    .map(name => {
      if (name.includes('-rtl')) {
        const n = name.replace('-rtl', '');
        excludedList.push(n);
        return `import ${jsUcWord(n)} from './${n}.png';`;
      }
      if (excludedList.includes(name)) {
        return undefined;
      }
      return `import ${jsUcWord(name)} from './${name}.png';`;
    })
    .join('\n');

  const propertiesJpg = imageFileNamesJpg()
    .map(name => {
      return `import ${jsUcWord(name)} from './${name}.jpg';`;
    })
    .join('\n');

  const propertiesSvg = imageFileNamesSvg()
    .map(name => {
      return `import ${jsUcWord(name)} from './${name}.svg';`;
    })
    .join('\n');

  const propertiesPngInside = imageFileNamesPng()
    .map(name => {
      if (name.includes('-rtl')) {
        const n = name.replace('-rtl', '');
        return `${jsUcWord(n)}`;
      }
      if (excludedList.includes(name)) {
        return undefined;
      }
      return `${jsUcWord(name)}`;
    })
    .join(',\n  ');

  const propertiesJpgInside = imageFileNamesJpg()
    .map(name => {
      return `${jsUcWord(name)}`;
    })
    .join(',\n  ');

  const propertiesSvgInside = imageFileNamesSvg()
    .map(name => {
      return `${jsUcWord(name)}`;
    })
    .join(',\n  ');

  const svgFileContentString = `/* eslint-disable global-require */

${propertiesSvg.length !== 0 && propertiesSvg}

export const SVGAssets = {
  ${propertiesSvg.length !== 0 ? `${propertiesSvgInside}` : ''}
}

`;
  const imageFileContentString = `/* eslint-disable global-require */

${propertiesPng.length !== 0 && propertiesPng}
${propertiesJpg.length !== 0 && propertiesJpg}

export const Images = {
  ${propertiesPngInside.length !== 0 ? `${propertiesPngInside},` : ''}
  ${propertiesJpgInside.length !== 0 ? `${propertiesJpgInside},` : ''}
};

`;

  fs.writeFileSync(basePath+'/images/index.ts', imageFileContentString, 'utf8');
  fs.writeFileSync(basePath+'/vectors/index.ts', svgFileContentString, 'utf8');
};
generate();
