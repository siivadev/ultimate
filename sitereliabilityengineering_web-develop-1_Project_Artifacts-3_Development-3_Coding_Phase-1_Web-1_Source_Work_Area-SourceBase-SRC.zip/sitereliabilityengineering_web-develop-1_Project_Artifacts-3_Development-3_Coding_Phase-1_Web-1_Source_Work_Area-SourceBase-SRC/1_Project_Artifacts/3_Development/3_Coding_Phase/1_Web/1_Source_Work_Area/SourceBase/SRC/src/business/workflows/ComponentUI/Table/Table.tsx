import { FC, useEffect, useState } from 'react';
import { useTable } from 'react-table';
import { TableProps } from '@business/interfaces/table';

export const Table: FC<TableProps> = ({ tableData, tableColumns }) => {
  const [data, setData] = useState(tableData);
  const [columns, setColumns] = useState(tableColumns);

  useEffect(() => {
    setData(tableData);
    setColumns(tableColumns);
  }, [tableData, tableColumns]);

  const { getTableProps, getTableBodyProps, headerGroups, rows, prepareRow } =
    useTable({ columns, data });

  return (
    <>
      <div className="overflow-x-auto">
        <table {...getTableProps()} className="table w-full">
          {/* head*/}
          <thead>
            {headerGroups.map((headerGroup, index) => (
              <tr key={index} {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map((column, ind) => (
                  <th key={ind} {...column.getHeaderProps()}>
                    {column.render('Header')}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody {...getTableBodyProps()}>
            {rows.map((row, index) => {
              prepareRow(row);
              return (
                <tr key={index} {...row.getRowProps()}>
                  {row.cells.map((cell, ind) => {
                    return (
                      <td key={ind} {...cell.getCellProps()}>
                        {cell.render('Cell')}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
};
