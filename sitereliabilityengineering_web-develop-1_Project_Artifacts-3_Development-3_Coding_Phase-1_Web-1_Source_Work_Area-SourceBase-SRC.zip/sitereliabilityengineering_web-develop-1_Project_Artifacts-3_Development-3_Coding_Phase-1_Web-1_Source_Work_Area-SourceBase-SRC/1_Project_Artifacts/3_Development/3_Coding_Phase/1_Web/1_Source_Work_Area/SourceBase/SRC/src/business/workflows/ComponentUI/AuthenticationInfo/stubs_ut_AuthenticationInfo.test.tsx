import React from 'react';
import { render } from '@testing-library/react';
import { ComponentProvider } from '@business/workflows/ComponentHigherOrder';
import { AuthenticationInfoProps } from '@business/interfaces/authentication-info';
import { AuthenticationInfo } from './AuthenticationInfo';

function AuthenticationInfoElement(mockProps: AuthenticationInfoProps) {
  return (
    <ComponentProvider>
      <AuthenticationInfo {...mockProps} />
    </ComponentProvider>
  );
}
describe('AuthenticationInfo', () => {
  it('renders with title and description', () => {
    const props = {
      title: 'Test Title',
      description: 'Test Description'
    };
    const { getByText } = render(<AuthenticationInfoElement {...props} />);
    expect(getByText(props.title)).toBeInTheDocument();
    expect(getByText(props.description)).toBeInTheDocument();
  });

  it('renders with image when provided', () => {
    const props = {
      title: 'Test Title',
      description: 'Test Description',
      image: 'test-image-url'
    };
    const { getByTestId } = render(<AuthenticationInfo {...props} />);
    expect(getByTestId('auth-info-image')).toHaveStyle(
      `background-image: url('${props.image}')`
    );
  });
});
