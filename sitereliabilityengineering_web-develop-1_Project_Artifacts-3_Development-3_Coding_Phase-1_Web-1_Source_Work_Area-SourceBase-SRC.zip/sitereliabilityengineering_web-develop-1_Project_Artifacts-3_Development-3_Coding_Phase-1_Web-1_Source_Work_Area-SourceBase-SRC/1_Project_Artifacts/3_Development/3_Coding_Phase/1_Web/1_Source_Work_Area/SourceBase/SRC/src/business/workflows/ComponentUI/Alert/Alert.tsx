import { FC, ReactNode, useEffect, useRef } from 'react';
import Image from 'next/image';
import { AlertProps } from '@business/interfaces/alert';
import { SVGAssets } from '@business/assets/vectors';

const getIcon = (type: string) => {
  let icon: ReactNode;
  switch (type) {
    case 'info':
      icon = (
        <SVGAssets.AlertInfo
          width={30}
          height={30}
          data-testid="info"
          style={{ color: 'var(--theme-info)' }}
        />
      );
      break;
    case 'warning':
      icon = (
        <SVGAssets.AlertWarning
          width={30}
          height={30}
          data-testid="warning"
          style={{ color: 'var(--theme-warning)' }}
        />
      );
      break;
    case 'success':
      icon = (
        <SVGAssets.AlertCheck
          width={30}
          height={30}
          data-testid="success"
          style={{ color: 'var(--theme-success)' }}
        />
      );
      break;
    case 'error':
    case 'failed':
      icon = (
        <SVGAssets.AlertError
          width={30}
          height={30}
          data-testid="error"
          style={{ color: 'var(--theme-error)' }}
        />
      );
      break;
    default:
      icon = <span data-testid="no-icon" />;
  }
  return icon;
};

export const Alert: FC<AlertProps> = ({
  type,
  heading,
  subHeading,
  wrapperClass,
  contentClass,
  onClose,
  isClosable,
  isFocusable,
  autoHide,
  autoHideDuration,
  onClick,
  customLeftIcon,
  customRightIcon,
  children
}) => {
  const alertRef = useRef(null);
  const icon = customLeftIcon ? customLeftIcon : getIcon(type);
  useEffect(() => {
    if (isFocusable) {
      alertRef.current.scrollIntoView({ block: 'center' });
    }
    if (autoHide) {
      setTimeout(() => {
        onClose();
      }, autoHideDuration);
    }
  }, []);

  return (
    <>
      <div
        ref={alertRef}
        className={`alert alert-${type} ${wrapperClass} ${
          typeof onClick !== 'undefined' ? 'cursor-pointer' : ''
        }`}
        onClick={onClick}>
        <div
          className={`flex items-center justify-between flex-row ${contentClass}`}>
          <div
            className={`flex ${
              subHeading ? 'items-start' : 'items-center'
            } text-width`}>
            {icon}
            <div className="text-left ml-2">
              <div>{heading}</div>
              {subHeading && (
                <div className="text-sm">
                  <span>{subHeading}</span>
                </div>
              )}
              {children}
            </div>
          </div>

          {customRightIcon
            ? customRightIcon
            : isClosable && (
                <div
                  className="cursor-pointer alert-close"
                  onClick={e => {
                    e.preventDefault();
                    e.stopPropagation();
                    onClose();
                  }}
                  data-testid="close-icon">
                  <Image
                    src="/images/close-white.svg"
                    alt="close"
                    className="w-3"
                    width={24}
                    height={24}
                  />
                </div>
              )}
        </div>
      </div>
    </>
  );
};

Alert.defaultProps = {
  type: 'success',
  onClose: () => {},
  isClosable: false,
  autoHide: true,
  autoHideDuration: 3000,
  contentClass: 'w-full',
  wrapperClass: '',
  isFocusable: true
};
