import React from 'react';
import {
  Header,
  Sidebar,
  TreeComponent
} from '@business/workflows/ComponentUI';

interface TreeNode {
  id: number;
  label: string;
  children: TreeNode[];
}

const data = [
  {
    id: 10,
    label: 'Client 1',
    children: [
      {
        id: 100,
        label: 'Project 1',
        children: [
          {
            id: 1000,
            label: 'Feature 1',
            children: [
              {
                id: 10000,
                label: 'Activity 1',
                children: [
                  {
                    id: 100000,
                    label: 'Intialize',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100001,
                    label: 'De Initialize',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100002,
                    label: 'Start',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100003,
                    label: 'Stop',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100004,
                    label: 'Pause',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100005,
                    label: 'Cancel',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100006,
                    label: 'Configure',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100007,
                    label: 'Create',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100008,
                    label: 'Edit',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100009,
                    label: 'Build',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100010,
                    label: 'Test',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100011,
                    label: 'Deploy',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100012,
                    label: 'Monitor',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100013,
                    label: 'Archive',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100014,
                    label: 'Cleanup',
                    children: [] as TreeNode[]
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        id: 101,
        label: 'Project 1',
        children: [
          {
            id: 1001,
            label: 'Feature 1',
            children: [
              {
                id: 10001,
                label: 'Activity 1',
                children: [
                  {
                    id: 100001,
                    label: 'Intialize',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100001,
                    label: 'De Initialize',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100002,
                    label: 'Start',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100003,
                    label: 'Stop',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100004,
                    label: 'Pause',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100005,
                    label: 'Cancel',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100006,
                    label: 'Configure',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100007,
                    label: 'Create',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100008,
                    label: 'Edit',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100009,
                    label: 'Build',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100010,
                    label: 'Test',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100011,
                    label: 'Deploy',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100012,
                    label: 'Monitor',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100013,
                    label: 'Archive',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100014,
                    label: 'Cleanup',
                    children: [] as TreeNode[]
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        id: 102,
        label: 'Project 1',
        children: [
          {
            id: 1002,
            label: 'Feature 1',
            children: [
              {
                id: 10002,
                label: 'Activity 1',
                children: [
                  {
                    id: 100000,
                    label: 'Intialize',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100001,
                    label: 'De Initialize',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100002,
                    label: 'Start',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100003,
                    label: 'Stop',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100004,
                    label: 'Pause',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100005,
                    label: 'Cancel',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100006,
                    label: 'Configure',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100007,
                    label: 'Create',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100008,
                    label: 'Edit',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100009,
                    label: 'Build',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100010,
                    label: 'Test',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100011,
                    label: 'Deploy',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100012,
                    label: 'Monitor',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100013,
                    label: 'Archive',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100014,
                    label: 'Cleanup',
                    children: [] as TreeNode[]
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  },
  {
    id: 10,
    label: 'Client 2',
    children: [
      {
        id: 100,
        label: 'Project 1',
        children: [
          {
            id: 1000,
            label: 'Feature 1',
            children: [
              {
                id: 10000,
                label: 'Activity 1',
                children: [
                  {
                    id: 100000,
                    label: 'Intialize',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100001,
                    label: 'De Initialize',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100002,
                    label: 'Start',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100003,
                    label: 'Stop',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100004,
                    label: 'Pause',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100005,
                    label: 'Cancel',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100006,
                    label: 'Configure',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100007,
                    label: 'Create',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100008,
                    label: 'Edit',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100009,
                    label: 'Build',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100010,
                    label: 'Test',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100011,
                    label: 'Deploy',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100012,
                    label: 'Monitor',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100013,
                    label: 'Archive',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100014,
                    label: 'Cleanup',
                    children: [] as TreeNode[]
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        id: 101,
        label: 'Project 1',
        children: [
          {
            id: 1001,
            label: 'Feature 1',
            children: [
              {
                id: 10001,
                label: 'Activity 1',
                children: [
                  {
                    id: 100001,
                    label: 'Intialize',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100001,
                    label: 'De Initialize',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100002,
                    label: 'Start',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100003,
                    label: 'Stop',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100004,
                    label: 'Pause',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100005,
                    label: 'Cancel',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100006,
                    label: 'Configure',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100007,
                    label: 'Create',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100008,
                    label: 'Edit',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100009,
                    label: 'Build',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100010,
                    label: 'Test',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100011,
                    label: 'Deploy',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100012,
                    label: 'Monitor',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100013,
                    label: 'Archive',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100014,
                    label: 'Cleanup',
                    children: [] as TreeNode[]
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        id: 102,
        label: 'Project 1',
        children: [
          {
            id: 1002,
            label: 'Feature 1',
            children: [
              {
                id: 10002,
                label: 'Activity 1',
                children: [
                  {
                    id: 100000,
                    label: 'Intialize',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100001,
                    label: 'De Initialize',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100002,
                    label: 'Start',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100003,
                    label: 'Stop',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100004,
                    label: 'Pause',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100005,
                    label: 'Cancel',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100006,
                    label: 'Configure',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100007,
                    label: 'Create',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100008,
                    label: 'Edit',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100009,
                    label: 'Build',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100010,
                    label: 'Test',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100011,
                    label: 'Deploy',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100012,
                    label: 'Monitor',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100013,
                    label: 'Archive',
                    children: [] as TreeNode[]
                  },
                  {
                    id: 100014,
                    label: 'Cleanup',
                    children: [] as TreeNode[]
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  }
];

export const Dashboard = () => {
  return (
    <main>
      <Header />
      <Sidebar />
      <div className="p-4 sm:ml-64">
        <div className="p-4 mt-14">
          <div className="block md:flex py-5">
            <div className="w-full md:w-1/12 mr-4 mb-4" />
            <div className="w-full md:w-10/12 mb-4">
              <div className="rounded-lg h-96 bg-white">
                <TreeComponent data={data} />
              </div>
            </div>
            <div className="w-full md:w-1/12 mr-4 mb-4" />
          </div>
        </div>
      </div>
    </main>
  );
};

export default Dashboard;
