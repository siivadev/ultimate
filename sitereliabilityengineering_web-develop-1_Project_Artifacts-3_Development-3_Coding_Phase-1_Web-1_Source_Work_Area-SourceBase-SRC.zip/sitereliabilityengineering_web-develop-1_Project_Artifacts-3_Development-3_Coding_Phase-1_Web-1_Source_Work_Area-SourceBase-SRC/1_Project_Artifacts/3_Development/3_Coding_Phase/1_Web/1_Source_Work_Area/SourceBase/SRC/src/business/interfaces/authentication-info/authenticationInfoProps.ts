import { ReactNode } from 'react';

export interface AuthenticationInfoProps {
  title?: ReactNode;
  description?: string;
  image?: any;
  titleContainer?: keyof JSX.IntrinsicElements;
  descriptionContainer?: keyof JSX.IntrinsicElements;
}
