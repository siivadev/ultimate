import React, { FC, forwardRef, useState } from 'react';
import { InputProps } from '@business/interfaces/input';
import { SVGAssets } from '@business/assets/vectors';

const getPasswordDecorator = (
  inputType: string,
  callback: (type: string) => void
) => {
  const iconSizeClass = 'w-8 h-5 cursor-pointer';
  if (inputType === 'text') {
    return (
      <SVGAssets.VisibilityOff
        className={iconSizeClass}
        onClick={() => {
          callback('password');
        }}
      />
    );
  } else {
    return (
      <SVGAssets.VisibilityOff
        className={iconSizeClass}
        onClick={() => {
          callback('text');
        }}
      />
    );
  }
};

export const InputField: FC<InputProps> = forwardRef<
  HTMLInputElement,
  InputProps
>(
  (
    {
      inputWrapperClassName,
      label,
      labelClassName,
      fieldSize,
      color,
      error,
      startDecorator,
      endDecorator,
      ...props
    },
    ref
  ) => {
    const actualType = props?.type;
    const [inputType, setInputType] = useState<string>(props?.type);
    function handleEndDecoratorVisibility(type: string) {
      setInputType(type);
    }

    return (
      <>
        <div className={`${inputWrapperClassName} ${error ? 'error' : color}`}>
          {startDecorator}
          <div className={label ? 'relative z-0 flex-col w-full' : ''}>
            <input
              {...props}
              ref={ref}
              id={props.name}
              type={inputType}
              data-testid={`input-field-${props.name}`}
            />
            {label && (
              <label
                htmlFor={props.name}
                data-testid="input-label"
                className={labelClassName}>
                {label}
              </label>
            )}
          </div>
          {actualType === 'password' && typeof endDecorator === 'undefined'
            ? getPasswordDecorator(inputType, handleEndDecoratorVisibility)
            : endDecorator}
        </div>
        {error && <div className="error-msg">{error}</div>}
      </>
    );
  }
);

InputField.displayName = 'InputField';
InputField.defaultProps = {
  type: 'text',
  placeholder: ' ',
  color: 'success',
  inputWrapperClassName: 'w-full input-wrapper',
  className:
    'pl-2 block py-2.5 px-0 w-full font-semibold bg-transparent appearance-none 0 focus:outline-none focus:ring-0 focus:border-blue-600 peer',
  labelClassName:
    'pl-2 absolute text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0  peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6'
};
