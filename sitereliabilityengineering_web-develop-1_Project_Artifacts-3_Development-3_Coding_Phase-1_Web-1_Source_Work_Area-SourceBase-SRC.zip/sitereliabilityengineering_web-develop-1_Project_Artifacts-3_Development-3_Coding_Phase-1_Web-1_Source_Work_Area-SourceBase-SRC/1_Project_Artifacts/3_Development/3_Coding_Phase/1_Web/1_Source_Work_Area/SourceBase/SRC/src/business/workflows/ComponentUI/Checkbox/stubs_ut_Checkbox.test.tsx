import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import { Checkbox } from './Checkbox';

describe('Checkbox component', () => {
  test('renders checkbox input element', () => {
    const { getByTestId } = render(<Checkbox name="test" />);
    expect(getByTestId('checkbox-field')).toBeInTheDocument();
    expect(getByTestId('checkbox-field-test')).toBeInTheDocument();
    expect(getByTestId('checkbox-field')).toContainHTML('<input id="test"');
  });

  test('renders label', () => {
    const { getByTestId } = render(
      <Checkbox name="test" label="Test Checkbox" />
    );
    expect(getByTestId('checkbox-label')).toBeInTheDocument();
    expect(getByTestId('checkbox-label')).toHaveTextContent('Test Checkbox');
  });

  //   test('calls onChange function when checkbox is clicked', () => {
  //     const onChange = jest.fn();
  //     const { getByTestId } = render(<Checkbox name="test" onChange={onChange} />);
  //     fireEvent.click(getByTestId('checkbox-field-test'));
  //     expect(onChange).toHaveBeenCalledTimes(1);
  //   });

  //   test('displays error message', () => {
  //     const { getByTestId } = render(<Checkbox name="test" error="Invalid checkbox value" />);
  //     expect(getByTestId('checkbox-field')).toContainHTML('<div class="invalid">Invalid checkbox value</div>');
  //   });

  //   test('applies custom class name', () => {
  //     const { getByTestId } = render(<Checkbox name="test" className="custom-class" />);
  //     expect(getByTestId('checkbox-field')).toHaveClass('custom-class');
  //   });
});
