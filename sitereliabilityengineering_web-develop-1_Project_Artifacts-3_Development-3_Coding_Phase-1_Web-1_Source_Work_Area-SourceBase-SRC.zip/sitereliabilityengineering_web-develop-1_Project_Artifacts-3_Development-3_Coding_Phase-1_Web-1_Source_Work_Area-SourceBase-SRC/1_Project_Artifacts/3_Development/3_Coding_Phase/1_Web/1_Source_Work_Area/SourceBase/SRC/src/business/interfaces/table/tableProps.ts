export interface TableProps {
  tableData?: any[];
  tableColumns?: any[];
}
