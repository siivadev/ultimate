import { FC } from 'react';
import { CheckboxProps } from '@business/interfaces/checkbox';

export const Checkbox: FC<CheckboxProps> = ({
  label,
  fieldSize,
  color,
  error,
  ...props
}) => {
  return (
    <>
      <div className={props.className} data-testid={'checkbox-field'}>
        <input
          {...props}
          type="checkbox"
          id={props.name}
          data-testid={`checkbox-field-${props.name}`}
        />
        {label && <label data-testid="checkbox-label">{label}</label>}
        <br />
      </div>
    </>
  );
};
